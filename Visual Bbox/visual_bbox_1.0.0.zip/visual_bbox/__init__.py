# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Visual Bbox",
    "author" : "Stups_Kiesel", 
    "description" : "STRG + #",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "HotKey",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import gpu
import gpu_extras


addon_keymaps = {}
_icons = None
nodetree = {'sna_show_bbox': False, 'sna_bbox_global': False, }
handler_B9F9D = []
class SNA_OT_Bbox_Toggle_265Eb(bpy.types.Operator):
    bl_idname = "sna.bbox_toggle_265eb"
    bl_label = "bbox_toggle"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        nodetree['sna_show_bbox'] = (not nodetree['sna_show_bbox'])
        if nodetree['sna_show_bbox']:
            handler_B9F9D.append(bpy.types.SpaceView3D.draw_handler_add(sna_drraw_bbox_204ED, (bpy.context.active_object.bound_box, ), 'WINDOW', 'POST_VIEW'))
            for a in bpy.context.screen.areas: a.tag_redraw()
        else:
            if handler_B9F9D:
                bpy.types.SpaceView3D.draw_handler_remove(handler_B9F9D[0], 'WINDOW')
                handler_B9F9D.pop(0)
                for a in bpy.context.screen.areas: a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_drraw_bbox_204ED(bbox_list):
    for i_96F0C in range(len(bbox_list)):
        coords = (bbox_list[i_96F0C], )
        shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        batch = gpu_extras.batch.batch_for_shader(shader, 'POINTS', {"pos": coords})
        shader.bind()
        shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
        gpu.state.point_size_set(7.0)
        gpu.state.depth_test_set('LESS')
        gpu.state.depth_mask_set(True)
        gpu.state.blend_set('ALPHA')
        batch.draw(shader)
    lines = [(bbox_list[0], bbox_list[1])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    lines = [(bbox_list[2], bbox_list[3])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    lines = [(bbox_list[4], bbox_list[5])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    lines = [(bbox_list[6], bbox_list[7])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    lines = [(bbox_list[0], bbox_list[3])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    lines = [(bbox_list[0], bbox_list[4])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    lines = [(bbox_list[1], bbox_list[2])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    lines = [(bbox_list[1], bbox_list[5])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    lines = [(bbox_list[2], bbox_list[6])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    lines = [(bbox_list[3], bbox_list[7])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    lines = [(bbox_list[4], bbox_list[7])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    lines = [(bbox_list[6], bbox_list[5])]
    coords = []
    indices = []
    for i, line in enumerate(lines):
        coords.extend(line)
        indices.append((i*2, i*2+1))
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    batch = gpu_extras.batch.batch_for_shader(shader, 'LINES', {"pos": coords}, indices=tuple(indices))
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
    gpu.state.line_width_set(1.5)
    gpu.state.depth_test_set('LESS')
    gpu.state.depth_mask_set(True)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Bbox_Toggle_265Eb)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.bbox_toggle_265eb', 'SLASH', 'PRESS',
        ctrl=True, alt=False, shift=False, repeat=False)
    addon_keymaps['ED18C'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Bbox_Toggle_265Eb)
    if handler_B9F9D:
        bpy.types.SpaceView3D.draw_handler_remove(handler_B9F9D[0], 'WINDOW')
        handler_B9F9D.pop(0)
