# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Extrude and Rotate",
    "author" : "Stups_Kiesel", 
    "description" : "Extrude and Rotate around axis.",
    "blender" : (3, 3, 2),
    "version" : (1, 0, 4),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
nodetree = {'sna_v_angle': 0.0, 'sna_v_steps': 0, 'sna_v_axis': '', 'sna_v_pivot': '', 'sna_v_vertex_group': False, 'sna_extrude_only': False, 'sna_extrude_distance': 0.0, }
class SNA_OT_Extruderotaterun_7F508(bpy.types.Operator):
    bl_idname = "sna.extruderotaterun_7f508"
    bl_label = "extrude-rotate-run"
    bl_description = "Execute Deformation"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        nodetree['sna_v_steps'] = bpy.context.scene.sna_steps
        nodetree['sna_v_angle'] = bpy.context.scene.sna_angle
        nodetree['sna_v_pivot'] = bpy.context.scene.sna_pivot
        nodetree['sna_extrude_distance'] = bpy.context.scene.sna_extrude_distance
        nodetree['sna_v_axis'] = bpy.context.scene.sna_axis
        from math import radians, degrees
        pivot = nodetree['sna_v_pivot']
        angle = nodetree['sna_v_angle']
        steps = nodetree['sna_v_steps']
        axis = nodetree['sna_v_axis']
        vx_group = nodetree['sna_v_vertex_group']
        extrude_only = nodetree['sna_extrude_only']
        extrude_distance = nodetree['sna_extrude_distance']
        active_object = bpy.context.view_layer.objects.active
        # calculate step angle
        step_angle = angle / steps
        # constraint_axis Boolien Vector calculation
        if axis == 'X':
            constraint_axis_var = True, False, False
        if axis == 'Y':
            constraint_axis_var = False, True, False
        if axis == 'Z':
            constraint_axis_var = False, False, True
        if vx_group == True:
            new_vertex_group = bpy.context.active_object.vertex_groups.new(name='vx_group')
            mode = bpy.context.active_object.mode
            # we need to switch from Edit mode to Object mode so the selection gets updated
            bpy.ops.object.mode_set(mode='OBJECT')
            vertex_group_data = [i.index for i in bpy.context.active_object.data.vertices if i.select]
            new_vertex_group.add(vertex_group_data, 1.0, 'ADD')
            # back to whatever mode we were in
            bpy.ops.object.mode_set(mode=mode)
            vertex_group_data.clear()
        if pivot == '3D Cursor':
            for i in range(steps):
                if vx_group == False:
                    # extrude 0
                    bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"use_normal_flip":False, "use_dissolve_ortho_edges":False, "mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, 0), "orient_axis_ortho":'X', "orient_type":'NORMAL', "orient_matrix":((0, -0, 1), (0, 1, 0), (-1, 0, 0)), "orient_matrix_type":'NORMAL', "constraint_axis":(False, False, True), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_elements":{'INCREMENT'}, "use_snap_project":False, "snap_target":'CLOSEST', "use_snap_self":True, "use_snap_edit":True, "use_snap_nonedit":True, "use_snap_selectable":False, "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "view2d_edge_pan":False, "release_confirm":False, "use_accurate":False, "use_automerge_and_split":False})
                    if extrude_only == False:
                        # rotate
                        bpy.ops.transform.rotate(value=radians(step_angle), center_override=bpy.context.scene.cursor.location, orient_axis=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                    else :
                        if axis == 'X':
                            bpy.ops.transform.translate(value=(extrude_distance, 0, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Y':
                            bpy.ops.transform.translate(value=(0, extrude_distance, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Z':       
                            bpy.ops.transform.translate(value=(0, 0, extrude_distance), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                if vx_group == True:
                    # extrude 0
                    bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"use_normal_flip":False, "use_dissolve_ortho_edges":False, "mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, 0), "orient_axis_ortho":'X', "orient_type":'NORMAL', "orient_matrix":((0, -0, 1), (0, 1, 0), (-1, 0, 0)), "orient_matrix_type":'NORMAL', "constraint_axis":(False, False, True), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_elements":{'INCREMENT'}, "use_snap_project":False, "snap_target":'CLOSEST', "use_snap_self":True, "use_snap_edit":True, "use_snap_nonedit":True, "use_snap_selectable":False, "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "view2d_edge_pan":False, "release_confirm":False, "use_accurate":False, "use_automerge_and_split":False})
                    if extrude_only == False:
                        # rotate
                        bpy.ops.transform.rotate(value=radians(step_angle), center_override=bpy.context.scene.cursor.location, orient_axis=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                    else :
                        if axis == 'X':
                            bpy.ops.transform.translate(value=(extrude_distance, 0, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Y':
                            bpy.ops.transform.translate(value=(0, extrude_distance, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Z':       
                            bpy.ops.transform.translate(value=(0, 0, extrude_distance), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                    bpy.ops.object.vertex_group_remove_from(use_all_groups=False, use_all_verts=False)
                    new_vertex_group = bpy.context.active_object.vertex_groups.new(name='vx_group.%s' % (i))
                    mode = bpy.context.active_object.mode
                    # we need to switch from Edit mode to Object mode so the selection gets updated
                    bpy.ops.object.mode_set(mode='OBJECT')
                    vertex_group_data = [i.index for i in bpy.context.active_object.data.vertices if i.select]
                    new_vertex_group.add(vertex_group_data, 1.0, 'ADD')
                    # back to whatever mode we were in
                    bpy.ops.object.mode_set(mode=mode)
                    vertex_group_data.clear()
        if pivot == 'World Origin':
            for i in range(steps):
                if vx_group == False:
                    # extrude 0
                    bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"use_normal_flip":False, "use_dissolve_ortho_edges":False, "mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, 0), "orient_axis_ortho":'X', "orient_type":'NORMAL', "orient_matrix":((0, -0, 1), (0, 1, 0), (-1, 0, 0)), "orient_matrix_type":'NORMAL', "constraint_axis":(False, False, True), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_elements":{'INCREMENT'}, "use_snap_project":False, "snap_target":'CLOSEST', "use_snap_self":True, "use_snap_edit":True, "use_snap_nonedit":True, "use_snap_selectable":False, "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "view2d_edge_pan":False, "release_confirm":False, "use_accurate":False, "use_automerge_and_split":False})
                    if extrude_only == False:
                        # rotate
                        bpy.ops.transform.rotate(value=radians(step_angle), center_override=(0.0, 0.0, 0.0), orient_axis=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                    else :
                        if axis == 'X':
                            bpy.ops.transform.translate(value=(extrude_distance, 0, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Y':
                            bpy.ops.transform.translate(value=(0, extrude_distance, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Z':       
                            bpy.ops.transform.translate(value=(0, 0, extrude_distance), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                if vx_group == True:
                    # extrude 0
                    bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"use_normal_flip":False, "use_dissolve_ortho_edges":False, "mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, 0), "orient_axis_ortho":'X', "orient_type":'NORMAL', "orient_matrix":((0, -0, 1), (0, 1, 0), (-1, 0, 0)), "orient_matrix_type":'NORMAL', "constraint_axis":(False, False, True), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_elements":{'INCREMENT'}, "use_snap_project":False, "snap_target":'CLOSEST', "use_snap_self":True, "use_snap_edit":True, "use_snap_nonedit":True, "use_snap_selectable":False, "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "view2d_edge_pan":False, "release_confirm":False, "use_accurate":False, "use_automerge_and_split":False})
                    if extrude_only == False:
                        # rotate
                        bpy.ops.transform.rotate(value=radians(step_angle), center_override=(0.0, 0.0, 0.0), orient_axis=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                    else :
                        if axis == 'X':
                            bpy.ops.transform.translate(value=(extrude_distance, 0, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Y':
                            bpy.ops.transform.translate(value=(0, extrude_distance, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Z':       
                            bpy.ops.transform.translate(value=(0, 0, extrude_distance), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                    bpy.ops.object.vertex_group_remove_from(use_all_groups=False, use_all_verts=False)
                    new_vertex_group = bpy.context.active_object.vertex_groups.new(name='vx_group.%s' % (i))
                    mode = bpy.context.active_object.mode
                    # we need to switch from Edit mode to Object mode so the selection gets updated
                    bpy.ops.object.mode_set(mode='OBJECT')
                    vertex_group_data = [i.index for i in bpy.context.active_object.data.vertices if i.select]
                    new_vertex_group.add(vertex_group_data, 1.0, 'ADD')
                    # back to whatever mode we were in
                    bpy.ops.object.mode_set(mode=mode)
                    vertex_group_data.clear()
        if pivot == 'Obj Origin':
            for i in range(steps):
                if vx_group == False:
                    # extrude 0
                    bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"use_normal_flip":False, "use_dissolve_ortho_edges":False, "mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, 0), "orient_axis_ortho":'X', "orient_type":'NORMAL', "orient_matrix":((0, -0, 1), (0, 1, 0), (-1, 0, 0)), "orient_matrix_type":'NORMAL', "constraint_axis":(False, False, True), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_elements":{'INCREMENT'}, "use_snap_project":False, "snap_target":'CLOSEST', "use_snap_self":True, "use_snap_edit":True, "use_snap_nonedit":True, "use_snap_selectable":False, "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "view2d_edge_pan":False, "release_confirm":False, "use_accurate":False, "use_automerge_and_split":False})
                    if extrude_only == False:
                        # rotate
                        bpy.ops.transform.rotate(value=radians(step_angle), center_override=(bpy.data.objects[bpy.context.view_layer.objects.active.name].location), orient_axis=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                    else :
                        if axis == 'X':
                            bpy.ops.transform.translate(value=(extrude_distance, 0, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Y':
                            bpy.ops.transform.translate(value=(0, extrude_distance, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Z':       
                            bpy.ops.transform.translate(value=(0, 0, extrude_distance), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                if vx_group == True:
                    # extrude 0
                    bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"use_normal_flip":False, "use_dissolve_ortho_edges":False, "mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, 0), "orient_axis_ortho":'X', "orient_type":'NORMAL', "orient_matrix":((0, -0, 1), (0, 1, 0), (-1, 0, 0)), "orient_matrix_type":'NORMAL', "constraint_axis":(False, False, True), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_elements":{'INCREMENT'}, "use_snap_project":False, "snap_target":'CLOSEST', "use_snap_self":True, "use_snap_edit":True, "use_snap_nonedit":True, "use_snap_selectable":False, "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "view2d_edge_pan":False, "release_confirm":False, "use_accurate":False, "use_automerge_and_split":False})
                    if extrude_only == False:
                        # rotate
                        bpy.ops.transform.rotate(value=radians(step_angle), center_override=(bpy.data.objects[bpy.context.view_layer.objects.active.name].location), orient_axis=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                    else :
                        if axis == 'X':
                            bpy.ops.transform.translate(value=(extrude_distance, 0, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Y':
                            bpy.ops.transform.translate(value=(0, extrude_distance, 0), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                        if axis == 'Z':       
                            bpy.ops.transform.translate(value=(0, 0, extrude_distance), orient_axis_ortho=axis, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(constraint_axis_var), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, snap=False, snap_elements={'INCREMENT'}, use_snap_project=False, snap_target='CLOSEST', use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True, use_snap_selectable=False)
                    bpy.ops.object.vertex_group_remove_from(use_all_groups=False, use_all_verts=False)
                    new_vertex_group = bpy.context.active_object.vertex_groups.new(name='vx_group.%s' % (i))
                    mode = bpy.context.active_object.mode
                    # we need to switch from Edit mode to Object mode so the selection gets updated
                    bpy.ops.object.mode_set(mode='OBJECT')
                    vertex_group_data = [i.index for i in bpy.context.active_object.data.vertices if i.select]
                    new_vertex_group.add(vertex_group_data, 1.0, 'ADD')
                    # back to whatever mode we were in
                    bpy.ops.object.mode_set(mode=mode)
                    vertex_group_data.clear()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Vertex_Group_01486(bpy.types.Operator):
    bl_idname = "sna.vertex_group_01486"
    bl_label = "vertex_group"
    bl_description = "Create vertex group on each step"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        nodetree['sna_v_vertex_group'] = (not nodetree['sna_v_vertex_group'])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Extrude_Only_86Ff1(bpy.types.Operator):
    bl_idname = "sna.extrude_only_86ff1"
    bl_label = "extrude_only"
    bl_description = "Extrude Only"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        nodetree['sna_extrude_only'] = (not nodetree['sna_extrude_only'])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Axis_Z_52442(bpy.types.Operator):
    bl_idname = "sna.set_axis_z_52442"
    bl_label = "set_axis_z"
    bl_description = "Deformation around Z"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.scene.sna_axis = 'Z'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Axis_X_A2F48(bpy.types.Operator):
    bl_idname = "sna.set_axis_x_a2f48"
    bl_label = "set_axis_x"
    bl_description = "Deformation around X"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.scene.sna_axis = 'X'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Axis_Y_3Cc47(bpy.types.Operator):
    bl_idname = "sna.set_axis_y_3cc47"
    bl_label = "set_axis_y"
    bl_description = "Deformation around Y"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.scene.sna_axis = 'Y'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_EXTRUDE_AND_ROTATE_21A9D(bpy.types.Panel):
    bl_label = 'Extrude and Rotate'
    bl_idname = 'SNA_PT_EXTRUDE_AND_ROTATE_21A9D'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Stups_Kiesel'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not 'EDIT_MESH'==bpy.context.mode))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_B4D99 = layout.row(heading='', align=True)
        row_B4D99.alert = False
        row_B4D99.enabled = True
        row_B4D99.active = True
        row_B4D99.use_property_split = True
        row_B4D99.use_property_decorate = True
        row_B4D99.scale_x = 1.0
        row_B4D99.scale_y = 1.0
        row_B4D99.alignment = 'Expand'.upper()
        if not True: row_B4D99.operator_context = "EXEC_DEFAULT"
        op = row_B4D99.operator('sna.set_axis_x_a2f48', text='X', icon_value=0, emboss=True, depress=('X' == bpy.context.scene.sna_axis))
        op = row_B4D99.operator('sna.set_axis_y_3cc47', text='Y', icon_value=0, emboss=True, depress=('Y' == bpy.context.scene.sna_axis))
        op = row_B4D99.operator('sna.set_axis_z_52442', text='Z', icon_value=0, emboss=True, depress=('Z' == bpy.context.scene.sna_axis))
        row_D9CF5 = layout.row(heading='', align=True)
        row_D9CF5.alert = False
        row_D9CF5.enabled = True
        row_D9CF5.active = True
        row_D9CF5.use_property_split = False
        row_D9CF5.use_property_decorate = False
        row_D9CF5.scale_x = 1.0
        row_D9CF5.scale_y = 1.0
        row_D9CF5.alignment = 'Expand'.upper()
        if not True: row_D9CF5.operator_context = "EXEC_DEFAULT"
        row_D9CF5.prop(bpy.context.scene, 'sna_pivot', text='Pivot', icon_value=0, emboss=True)
        if (not nodetree['sna_extrude_only']):
            row_C95C1 = layout.row(heading='', align=True)
            row_C95C1.alert = False
            row_C95C1.enabled = True
            row_C95C1.active = True
            row_C95C1.use_property_split = False
            row_C95C1.use_property_decorate = False
            row_C95C1.scale_x = 1.0
            row_C95C1.scale_y = 1.0
            row_C95C1.alignment = 'Expand'.upper()
            if not True: row_C95C1.operator_context = "EXEC_DEFAULT"
            row_C95C1.prop(bpy.context.scene, 'sna_angle', text='Angle:', icon_value=0, emboss=True)
        else:
            row_A160F = layout.row(heading='', align=False)
            row_A160F.alert = False
            row_A160F.enabled = True
            row_A160F.active = True
            row_A160F.use_property_split = False
            row_A160F.use_property_decorate = False
            row_A160F.scale_x = 1.0
            row_A160F.scale_y = 1.0
            row_A160F.alignment = 'Expand'.upper()
            if not True: row_A160F.operator_context = "EXEC_DEFAULT"
            row_A160F.prop(bpy.context.scene, 'sna_extrude_distance', text='Step lenth', icon_value=0, emboss=True)
        row_E10F8 = layout.row(heading='', align=True)
        row_E10F8.alert = False
        row_E10F8.enabled = True
        row_E10F8.active = True
        row_E10F8.use_property_split = False
        row_E10F8.use_property_decorate = False
        row_E10F8.scale_x = 1.0
        row_E10F8.scale_y = 1.0
        row_E10F8.alignment = 'Expand'.upper()
        if not True: row_E10F8.operator_context = "EXEC_DEFAULT"
        row_E10F8.prop(bpy.context.scene, 'sna_steps', text='Steps:', icon_value=0, emboss=True)
        row_EBC3E = layout.row(heading='', align=True)
        row_EBC3E.alert = False
        row_EBC3E.enabled = (not (bpy.context.active_object.data.total_vert_sel == 0))
        row_EBC3E.active = True
        row_EBC3E.use_property_split = False
        row_EBC3E.use_property_decorate = False
        row_EBC3E.scale_x = 1.0
        row_EBC3E.scale_y = 1.0
        row_EBC3E.alignment = 'Expand'.upper()
        if not True: row_EBC3E.operator_context = "EXEC_DEFAULT"
        row_BD407 = row_EBC3E.row(heading='', align=True)
        row_BD407.alert = False
        row_BD407.enabled = True
        row_BD407.active = True
        row_BD407.use_property_split = False
        row_BD407.use_property_decorate = False
        row_BD407.scale_x = 1.0
        row_BD407.scale_y = 1.0
        row_BD407.alignment = 'Expand'.upper()
        if not True: row_BD407.operator_context = "EXEC_DEFAULT"
        op = row_BD407.operator('sna.vertex_group_01486', text='', icon_value=201, emboss=True, depress=nodetree['sna_v_vertex_group'])
        op = row_EBC3E.operator('sna.extrude_only_86ff1', text='', icon_value=556, emboss=True, depress=nodetree['sna_extrude_only'])
        op = row_EBC3E.operator('sna.extruderotaterun_7f508', text='Run ...', icon_value=0, emboss=True, depress=False)


class SNA_OT_Dellete_All_Vertex_Groups_30828(bpy.types.Operator):
    bl_idname = "sna.dellete_all_vertex_groups_30828"
    bl_label = "dellete all vertex groups"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.vertex_groups.clear()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_node_F8A69(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_node_F8A69'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'data'
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'DATA_PT_vertex_groups'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_F5B0D = layout.row(heading='', align=False)
        row_F5B0D.alert = True
        row_F5B0D.enabled = True
        row_F5B0D.active = True
        row_F5B0D.use_property_split = False
        row_F5B0D.use_property_decorate = False
        row_F5B0D.scale_x = 1.0
        row_F5B0D.scale_y = 1.0
        row_F5B0D.alignment = 'Expand'.upper()
        if not True: row_F5B0D.operator_context = "EXEC_DEFAULT"
        op = row_F5B0D.operator('sna.dellete_all_vertex_groups_30828', text='Delete all Vertex Groups', icon_value=201, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_angle = bpy.props.FloatProperty(name='angle', description='Set total angle of deformation', default=90.0, subtype='NONE', unit='NONE', soft_min=-90.0, soft_max=90.0, step=3, precision=3)
    bpy.types.Scene.sna_steps = bpy.props.IntProperty(name='steps', description='Set total subdevision steps', default=96, subtype='NONE', min=1, soft_max=96)
    bpy.types.Scene.sna_axis = bpy.props.StringProperty(name='axis', description='', default='Z', subtype='NONE', maxlen=1)
    bpy.types.Scene.sna_pivot = bpy.props.EnumProperty(name='pivot', description='Select The Pivot Point, where the selection get deformed around.', items=[('3D Cursor', '3D Cursor', '', 552, 0), ('World Origin', 'World Origin', '', 82, 1), ('Obj Origin', 'Obj Origin', '', 159, 2)])
    bpy.types.Scene.sna_extrude_distance = bpy.props.FloatProperty(name='Extrude_distance', description='', default=1.0, subtype='NONE', unit='NONE', step=3, precision=3)
    bpy.utils.register_class(SNA_OT_Extruderotaterun_7F508)
    bpy.utils.register_class(SNA_OT_Vertex_Group_01486)
    bpy.utils.register_class(SNA_OT_Extrude_Only_86Ff1)
    bpy.utils.register_class(SNA_OT_Set_Axis_Z_52442)
    bpy.utils.register_class(SNA_OT_Set_Axis_X_A2F48)
    bpy.utils.register_class(SNA_OT_Set_Axis_Y_3Cc47)
    bpy.utils.register_class(SNA_PT_EXTRUDE_AND_ROTATE_21A9D)
    bpy.utils.register_class(SNA_OT_Dellete_All_Vertex_Groups_30828)
    bpy.utils.register_class(SNA_PT_node_F8A69)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_extrude_distance
    del bpy.types.Scene.sna_pivot
    del bpy.types.Scene.sna_axis
    del bpy.types.Scene.sna_steps
    del bpy.types.Scene.sna_angle
    bpy.utils.unregister_class(SNA_OT_Extruderotaterun_7F508)
    bpy.utils.unregister_class(SNA_OT_Vertex_Group_01486)
    bpy.utils.unregister_class(SNA_OT_Extrude_Only_86Ff1)
    bpy.utils.unregister_class(SNA_OT_Set_Axis_Z_52442)
    bpy.utils.unregister_class(SNA_OT_Set_Axis_X_A2F48)
    bpy.utils.unregister_class(SNA_OT_Set_Axis_Y_3Cc47)
    bpy.utils.unregister_class(SNA_PT_EXTRUDE_AND_ROTATE_21A9D)
    bpy.utils.unregister_class(SNA_OT_Dellete_All_Vertex_Groups_30828)
    bpy.utils.unregister_class(SNA_PT_node_F8A69)
