# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Copy Paste Vertex Z",
    "author" : "Stups_Kiesel", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "Mesh Edit > Vertex context menu",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import bmesh


addon_keymaps = {}
_icons = None
vertex_mover = {'sna_old_x': 0.0, 'sna_old_y': 0.0, 'sna_old_z': 0.0, 'sna_new_x': 0.0, 'sna_new_y': 0.0, 'sna_new_z': 0.0, }


def sna_toggle_edit_mode_2EA60_4F1E3():
    bpy.ops.object.editmode_toggle()
    return


def sna_toggle_edit_mode_2EA60_B2DFD():
    bpy.ops.object.editmode_toggle()
    return


def sna_toggle_edit_mode_2EA60_3F740():
    bpy.ops.object.editmode_toggle()
    return


def sna_toggle_edit_mode_2EA60_CC456():
    bpy.ops.object.editmode_toggle()
    return


class SNA_OT_Copy_Z_1A9Bb(bpy.types.Operator):
    bl_idname = "sna.copy_z_1a9bb"
    bl_label = "copy_z"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_toggle_edit_mode_2EA60_4F1E3()
        bpy.context.scene.sna_z_value = 0.0
        bm_56C8D = bmesh.new()
        if bpy.context.view_layer.objects.active:
            if bpy.context.view_layer.objects.active.mode == 'EDIT' and False:
                bm_56C8D = bmesh.from_edit_mesh(bpy.context.view_layer.objects.active.data)
            else:
                if False:
                    dg = bpy.context.evaluated_depsgraph_get()
                    bm_56C8D.from_mesh(bpy.context.view_layer.objects.active.evaluated_get(dg).to_mesh())
                else:
                    bm_56C8D.from_mesh(bpy.context.view_layer.objects.active.data)
        if False:
            bm_56C8D.transform(bpy.context.view_layer.objects.active.matrix_world)
        bm_56C8D.verts.ensure_lookup_table()
        bm_56C8D.faces.ensure_lookup_table()
        bm_56C8D.edges.ensure_lookup_table()
        for i_1F3FA in range(len(bm_56C8D.verts)):
            if bpy.context.active_object.data.vertices[bm_56C8D.verts[i_1F3FA].index].select:
                bpy.context.scene.sna_z_value = bm_56C8D.verts[i_1F3FA].co[2]
                sna_toggle_edit_mode_2EA60_B2DFD()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Paste_Z_A90A7(bpy.types.Operator):
    bl_idname = "sna.paste_z_a90a7"
    bl_label = "paste_z"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_toggle_edit_mode_2EA60_3F740()
        bm_93A22 = bmesh.new()
        if bpy.context.view_layer.objects.active:
            if bpy.context.view_layer.objects.active.mode == 'EDIT' and False:
                bm_93A22 = bmesh.from_edit_mesh(bpy.context.view_layer.objects.active.data)
            else:
                if False:
                    dg = bpy.context.evaluated_depsgraph_get()
                    bm_93A22.from_mesh(bpy.context.view_layer.objects.active.evaluated_get(dg).to_mesh())
                else:
                    bm_93A22.from_mesh(bpy.context.view_layer.objects.active.data)
        if False:
            bm_93A22.transform(bpy.context.view_layer.objects.active.matrix_world)
        bm_93A22.verts.ensure_lookup_table()
        bm_93A22.faces.ensure_lookup_table()
        bm_93A22.edges.ensure_lookup_table()
        for i_3C685 in range(len(bm_93A22.verts)):
            if bpy.context.active_object.data.vertices[bm_93A22.verts[i_3C685].index].select:
                sna_vertex_xyz_set_403F4(bm_93A22.verts[i_3C685].index, '', '', bpy.context.scene.sna_z_value)
        sna_toggle_edit_mode_2EA60_CC456()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_mt_edit_mesh_context_menu_E6EFE(self, context):
    if not (False):
        layout = self.layout
        if bpy.context.tool_settings.mesh_select_mode[0]:
            op = layout.operator('sna.copy_z_1a9bb', text='Copy Z', icon_value=598, emboss=True, depress=False)
        if bpy.context.tool_settings.mesh_select_mode[0]:
            op = layout.operator('sna.paste_z_a90a7', text='Paste Z ' + '(' + str(round(bpy.context.scene.sna_z_value, abs(3))) + ')', icon_value=599, emboss=True, depress=False)


def sna_vertex_xyz_set_403F4(vertex_id, X, Y, Z):
    vertex_mover['sna_old_x'] = 0.0
    vertex_mover['sna_old_y'] = 0.0
    vertex_mover['sna_old_z'] = 0.0
    vertex_mover['sna_new_x'] = 0.0
    vertex_mover['sna_new_y'] = 0.0
    vertex_mover['sna_new_z'] = 0.0
    vertex_mover['sna_old_x'] = bpy.context.object.data.vertices[vertex_id].co[0]
    vertex_mover['sna_old_y'] = bpy.context.object.data.vertices[vertex_id].co[1]
    vertex_mover['sna_old_z'] = bpy.context.object.data.vertices[vertex_id].co[2]
    vertex_mover['sna_new_x'] = (vertex_mover['sna_old_x'] if ('' == X) else X)
    vertex_mover['sna_new_y'] = (vertex_mover['sna_old_y'] if ('' == Y) else Y)
    vertex_mover['sna_new_z'] = (vertex_mover['sna_old_z'] if ('' == Z) else Z)
    bpy.context.object.data.vertices[vertex_id].co = (vertex_mover['sna_new_x'], vertex_mover['sna_new_y'], vertex_mover['sna_new_z'])


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_z_value = bpy.props.FloatProperty(name='Z Value', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.utils.register_class(SNA_OT_Copy_Z_1A9Bb)
    bpy.utils.register_class(SNA_OT_Paste_Z_A90A7)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.append(sna_add_to_view3d_mt_edit_mesh_context_menu_E6EFE)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_z_value
    bpy.utils.unregister_class(SNA_OT_Copy_Z_1A9Bb)
    bpy.utils.unregister_class(SNA_OT_Paste_Z_A90A7)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(sna_add_to_view3d_mt_edit_mesh_context_menu_E6EFE)
