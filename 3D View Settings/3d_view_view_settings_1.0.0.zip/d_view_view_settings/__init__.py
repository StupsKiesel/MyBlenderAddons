# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "3D View: View Settings",
    "author" : "Stups_Kiesel", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent


addon_keymaps = {}
_icons = None


def sna_viewport_data_view_3d_13599_BC381():
    area = None
    try:
        for a in bpy.data.window_managers[0].windows[0].screen.areas:
            if a.type == "VIEW_3D":
                area = a
    except:
        area = None
    area = area
    r3d = None
    view_mat = None
    out_view_distance = None
    out_view_location = None
    out_view_rotation = None
    out_view_camera_zoom = None
    out_view_camera_offset = None
    view_matrix_loc = None
    view_matrix_rot = None
    view_matrix_sca = None
    if area is not None:
        # print(dir(area))
        r3d = area.spaces[0].region_3d
        view_mat = r3d.view_matrix
        view_matrix_loc, view_matrix_rot, view_matrix_sca = view_mat.decompose()
        out_view_distance = r3d.view_distance
        out_view_location = r3d.view_location
        out_view_rotation = r3d.view_rotation
        out_view_camera_zoom = r3d.view_camera_zoom
        out_view_camera_offset = r3d.view_camera_offset
    return [(area != 'None'), r3d, view_mat[0], view_matrix_loc, view_matrix_rot, view_matrix_sca, out_view_distance, out_view_location, out_view_rotation, out_view_camera_zoom, out_view_camera_offset, area]


@persistent
def load_post_handler_408E1(dummy):
    sna_viewport_data_view_3d_13599_BC381()[11].spaces[0].lens = bpy.context.preferences.addons['d_view_view_settings'].preferences.sna_focal_length
    sna_viewport_data_view_3d_13599_BC381()[11].spaces[0].clip_start = bpy.context.preferences.addons['d_view_view_settings'].preferences.sna_clip_start
    sna_viewport_data_view_3d_13599_BC381()[11].spaces[0].clip_end = bpy.context.preferences.addons['d_view_view_settings'].preferences.sna_end


class SNA_AddonPreferences_755C5(bpy.types.AddonPreferences):
    bl_idname = 'd_view_view_settings'
    sna_focal_length: bpy.props.FloatProperty(name='Focal Length', description='', default=0.0, subtype='NONE', unit='NONE', min=1.0, step=1, precision=3)
    sna_clip_start: bpy.props.FloatProperty(name='Clip Start', description='', default=0.0, subtype='NONE', unit='NONE', min=0.0010000000474974513, step=1, precision=3)
    sna_end: bpy.props.FloatProperty(name='End', description='', default=0.0, subtype='NONE', unit='NONE', min=0.0, step=1, precision=3)

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout.label(text='On Blender Load this settings are applied to the 3D View Space', icon_value=0)
            layout.prop(bpy.context.preferences.addons['d_view_view_settings'].preferences, 'sna_focal_length', text='Focal Length', icon_value=0, emboss=True)
            layout.prop(bpy.context.preferences.addons['d_view_view_settings'].preferences, 'sna_clip_start', text='Clip Start', icon_value=0, emboss=True)
            layout.prop(bpy.context.preferences.addons['d_view_view_settings'].preferences, 'sna_end', text='End', icon_value=0, emboss=True)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.app.handlers.load_post.append(load_post_handler_408E1)
    bpy.utils.register_class(SNA_AddonPreferences_755C5)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.app.handlers.load_post.remove(load_post_handler_408E1)
    bpy.utils.unregister_class(SNA_AddonPreferences_755C5)
