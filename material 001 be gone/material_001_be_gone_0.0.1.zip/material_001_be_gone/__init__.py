# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Material *.001 be GONE!",
    "author" : "Stups_Kiesel", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (0, 0, 1),
    "location" : "Properties > Material",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None


def sna_add_to_eevee_material_pt_context_material_59F23(self, context):
    if not (False):
        layout = self.layout
        row_785FE = layout.row(heading='', align=False)
        row_785FE.alert = True
        row_785FE.enabled = True
        row_785FE.active = True
        row_785FE.use_property_split = False
        row_785FE.use_property_decorate = False
        row_785FE.scale_x = 1.0
        row_785FE.scale_y = 1.0
        row_785FE.alignment = 'Right'.upper()
        if not True: row_785FE.operator_context = "EXEC_DEFAULT"
        op = row_785FE.operator('sna.mat_duplicate_be_gone_9c3ee', text='', icon_value=181, emboss=True, depress=False)


class SNA_OT_Mat_Duplicate_Be_Gone_9C3Ee(bpy.types.Operator):
    bl_idname = "sna.mat_duplicate_be_gone_9c3ee"
    bl_label = "mat_duplicate_be_gone"
    bl_description = "Replace all *.001 materials with the orginal material"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_36BAC in range(len(bpy.context.active_object.material_slots)):
            if '.' in str(bpy.context.active_object.material_slots[i_36BAC]).split('"')[1]:
                old_mat_name = str(bpy.context.active_object.material_slots[i_36BAC]).split('"')[1]
                new_mat_name = str(bpy.context.active_object.material_slots[i_36BAC]).split('"')[1][:int(len(str(bpy.context.active_object.material_slots[i_36BAC]).split('"')[1]) - 4.0)]
                old_mat = bpy.data.materials.get(old_mat_name)
                new_mat = bpy.data.materials.get(new_mat_name)
                old_mat.user_remap(new_mat)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.EEVEE_MATERIAL_PT_context_material.prepend(sna_add_to_eevee_material_pt_context_material_59F23)
    bpy.utils.register_class(SNA_OT_Mat_Duplicate_Be_Gone_9C3Ee)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.types.EEVEE_MATERIAL_PT_context_material.remove(sna_add_to_eevee_material_pt_context_material_59F23)
    bpy.utils.unregister_class(SNA_OT_Mat_Duplicate_Be_Gone_9C3Ee)
