# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Tic Tac Toe",
    "author" : "StupsKiesel", 
    "description" : "Just a mini game",
    "blender" : (4, 0, 0),
    "version" : (1, 0, 1),
    "location" : "Text editor",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import random


addon_keymaps = {}
_icons = None
functions = {'sna_valuelist2boollist': [], 'sna_testiffieldiswon': False, 'sna_testiffieldiswonpattern': [], }
ttt_super_field = {'sna_superboardvalues': [], 'sna_superboardallarmvalues': [], 'sna_bordwinvalues': [], }


def random_integer(min, max, seed):
    random.seed(seed)
    return random.randint(int(min), int(max))


def sna_list_item_replace_9E3B4_39867(List, Index, Data):
    List = List
    Index = Index
    Data = Data
    newList = None
    List[Index] = Data
    newList = List
    return newList


def sna_list_item_replace_9E3B4_B6ED0(List, Index, Data):
    List = List
    Index = Index
    Data = Data
    newList = None
    List[Index] = Data
    newList = List
    return newList


def sna_list_item_replace_9E3B4_28483(List, Index, Data):
    List = List
    Index = Index
    Data = Data
    newList = None
    List[Index] = Data
    newList = List
    return newList


def sna_list_item_replace_9E3B4_91DEF(List, Index, Data):
    List = List
    Index = Index
    Data = Data
    newList = None
    List[Index] = Data
    newList = List
    return newList


def sna_list_item_replace_9E3B4_904ED(List, Index, Data):
    List = List
    Index = Index
    Data = Data
    newList = None
    List[Index] = Data
    newList = List
    return newList


def sna_update_sna_activeboardindex_A7D60(self, context):
    sna_updated_prop = self.sna_activeboardindex
    if bpy.context.scene.sna_supermode:
        pass
    else:
        bpy.context.scene.sna_activeboardindex = 0


class SNA_OT_Bot_A0C8D(bpy.types.Operator):
    bl_idname = "sna.bot_a0c8d"
    bl_label = "bot"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_overwrite: bpy.props.BoolProperty(name='overwrite', description='', default=False)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if ((not bpy.context.scene.sna_supermode) and (ttt_super_field['sna_bordwinvalues'][bpy.context.scene.sna_activeboardindex] != -1)):
            pass
        else:
            if bpy.context.scene.sna_multiplayer:
                pass
            else:
                if (self.sna_overwrite if self.sna_overwrite else bpy.context.scene.sna_activeplayer):
                    if (bpy.context.scene.sna_activeboardindex == -1):
                        boollist_0_33fc9 = sna_ttt_valuelist2boollist_1E2FA(ttt_super_field['sna_bordwinvalues'], -1)
                        if True in boollist_0_33fc9:
                            output_0_c02ff = sna_botcellselect_3B722(boollist_0_33fc9)
                            boollist_0_d6e31 = sna_ttt_valuelist2boollist_1E2FA(ttt_super_field['sna_superboardvalues'][output_0_c02ff], -1)
                            output_0_4ebd7 = sna_botcellselect_3B722(boollist_0_d6e31)
                            bpy.ops.sna.press_c0162(sna_player=bpy.context.scene.sna_activeplayer, sna_cellindex=output_0_4ebd7, sna_fieldindex=output_0_c02ff)
                        else:
                            sna_gamewinevent_16BFA()
                            bpy.context.scene.sna_text = 'Draw!'
                            bpy.context.scene.sna_ingame = False
                    else:
                        if ((not bpy.context.scene.sna_supermode) or -1 in ttt_super_field['sna_superboardvalues'][bpy.context.scene.sna_activeboardindex]):
                            boollist_0_d4448 = sna_ttt_valuelist2boollist_1E2FA(ttt_super_field['sna_superboardvalues'][bpy.context.scene.sna_activeboardindex], -1)
                            output_0_833ef = sna_botcellselect_3B722(boollist_0_d4448)
                            bpy.ops.sna.press_c0162(sna_player=bpy.context.scene.sna_activeplayer, sna_cellindex=output_0_833ef, sna_fieldindex=bpy.context.scene.sna_activeboardindex)
                        else:
                            sna_gamewinevent_16BFA()
                            bpy.context.scene.sna_text = 'Draw!'
                            bpy.context.scene.sna_ingame = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_random_24F11():
    return random_integer(0.0, 8.0, None)


def sna_botcellselect_3B722(validNumbersBoolList):
    output_0_5be79 = sna_random_24F11()
    if validNumbersBoolList[output_0_5be79]:
        pass
    else:
        output_0_90150 = sna_botcellselect_3B722(validNumbersBoolList)
    return (output_0_5be79 if validNumbersBoolList[output_0_5be79] else output_0_90150)


class SNA_OT_Press_C0162(bpy.types.Operator):
    bl_idname = "sna.press_c0162"
    bl_label = "press"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_player: bpy.props.BoolProperty(name='player', description='', default=False)
    sna_cellindex: bpy.props.IntProperty(name='cellIndex', description='', default=0, subtype='NONE', min=0, max=8)
    sna_fieldindex: bpy.props.IntProperty(name='fieldIndex', description='', default=0, subtype='NONE', min=0, max=8)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        ttt_super_field['sna_superboardvalues'] = sna_list_item_replace_9E3B4_39867(ttt_super_field['sna_superboardvalues'], self.sna_fieldindex, sna_list_item_replace_9E3B4_B6ED0(ttt_super_field['sna_superboardvalues'][self.sna_fieldindex], self.sna_cellindex, (2 if self.sna_player else 1)))
        finnished_0_d716a, boolpattern_1_d716a = sna_ttt_testiffieldiswon_78FFF(sna_list_item_replace_9E3B4_B6ED0(ttt_super_field['sna_superboardvalues'][self.sna_fieldindex], self.sna_cellindex, (2 if self.sna_player else 1)), (2 if self.sna_player else 1))
        if finnished_0_d716a:
            ttt_super_field['sna_bordwinvalues'] = sna_list_item_replace_9E3B4_28483(ttt_super_field['sna_bordwinvalues'], self.sna_fieldindex, (2 if self.sna_player else 1))
            ttt_super_field['sna_superboardallarmvalues'] = sna_list_item_replace_9E3B4_91DEF(ttt_super_field['sna_superboardallarmvalues'], self.sna_fieldindex, boolpattern_1_d716a)
        else:
            if -1 in sna_list_item_replace_9E3B4_B6ED0(ttt_super_field['sna_superboardvalues'][self.sna_fieldindex], self.sna_cellindex, (2 if self.sna_player else 1)):
                pass
            else:
                ttt_super_field['sna_bordwinvalues'] = sna_list_item_replace_9E3B4_904ED(ttt_super_field['sna_bordwinvalues'], self.sna_fieldindex, 0)
        sna_gamewinevent_16BFA()
        bpy.context.scene.sna_activeboardindex = self.sna_cellindex
        if (bpy.context.scene.sna_activeboardindex != -1):
            if (ttt_super_field['sna_bordwinvalues'][bpy.context.scene.sna_activeboardindex] >= 0):
                bpy.context.scene.sna_activeboardindex = -1
            if -1 in ttt_super_field['sna_superboardvalues'][bpy.context.scene.sna_activeboardindex]:
                pass
            else:
                bpy.context.scene.sna_activeboardindex = -1
        bpy.context.scene.sna_activeplayer = (not bpy.context.scene.sna_activeplayer)
        bpy.ops.sna.bot_a0c8d(sna_overwrite=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_gamewinevent_16BFA():
    finnished_0_81a91, boolpattern_1_81a91 = sna_ttt_testiffieldiswon_78FFF(ttt_super_field['sna_bordwinvalues'], 1)
    if finnished_0_81a91:
        bpy.context.scene.sna_text = 'You win!'
        bpy.context.scene.sna_ingame = False
    else:
        finnished_0_456a8, boolpattern_1_456a8 = sna_ttt_testiffieldiswon_78FFF(ttt_super_field['sna_bordwinvalues'], 2)
        if finnished_0_456a8:
            bpy.context.scene.sna_text = 'Bot wins!'
            bpy.context.scene.sna_ingame = False


def sna_ttt_valuelist2boollist_1E2FA(valueList, trueValue):
    functions['sna_valuelist2boollist'] = []
    for i_84102 in range(len(valueList)):
        functions['sna_valuelist2boollist'].append((True if (valueList[i_84102] == trueValue) else False))
    return functions['sna_valuelist2boollist']


def sna_ttt_possiblewinpattern_C94D0():
    return [[True, True, True, False, False, False, False, False, False], [False, False, False, True, True, True, False, False, False], [False, False, False, False, False, False, True, True, True], [True, False, False, True, False, False, True, False, False], [False, True, False, False, True, False, False, True, False], [False, False, True, False, False, True, False, False, True], [True, False, False, False, True, False, False, False, True], [False, False, True, False, True, False, True, False, False]]


def sna_ttt_testiffieldiswon_78FFF(Field, trueValue):
    functions['sna_testiffieldiswonpattern'] = []
    functions['sna_testiffieldiswon'] = False
    boollist_0_6348b = sna_ttt_valuelist2boollist_1E2FA(Field, trueValue)
    for i_43E1C in range(len(sna_ttt_possiblewinpattern_C94D0())):
        winner_0_585b4 = sna_ttt_paternfinder_232C0(sna_ttt_possiblewinpattern_C94D0()[i_43E1C], boollist_0_6348b)
        if winner_0_585b4:
            functions['sna_testiffieldiswon'] = True
            functions['sna_testiffieldiswonpattern'] = sna_ttt_possiblewinpattern_C94D0()[i_43E1C]
    return [functions['sna_testiffieldiswon'], functions['sna_testiffieldiswonpattern']]


def sna_ttt_paternfinder_232C0(pattern, boolvaluelist):
    pattern = pattern
    boolvaluelist = boolvaluelist
    winner = None
    ITP = [i for i,val in enumerate(pattern) if val==True]
    winner = False
    if boolvaluelist[ITP[0]] == True and boolvaluelist[ITP[1]] == True and boolvaluelist[ITP[2]] == True:
        winner = True
    return winner


def sna_ttt_cell_074DA(layout_function, cellindex, fieldindex, enable):
    row_EEAB9 = layout_function.row(heading='', align=True)
    row_EEAB9.alert = ttt_super_field['sna_superboardallarmvalues'][fieldindex][cellindex]
    row_EEAB9.enabled = (enable and (ttt_super_field['sna_superboardvalues'][fieldindex][cellindex] < 0) and (ttt_super_field['sna_bordwinvalues'][fieldindex] < 0))
    row_EEAB9.active = True
    row_EEAB9.use_property_split = False
    row_EEAB9.use_property_decorate = False
    row_EEAB9.scale_x = bpy.context.scene.sna_cellsize
    row_EEAB9.scale_y = bpy.context.scene.sna_cellsize
    row_EEAB9.alignment = 'Expand'.upper()
    row_EEAB9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = row_EEAB9.operator('sna.press_c0162', text='', icon_value=(12 if (ttt_super_field['sna_superboardvalues'][fieldindex][cellindex] == 2) else (33 if (ttt_super_field['sna_superboardvalues'][fieldindex][cellindex] == 1) else (32 if (ttt_super_field['sna_superboardvalues'][fieldindex][cellindex] == 0) else 101))), emboss=(not (ttt_super_field['sna_bordwinvalues'][fieldindex] > -1)), depress=False)
    op.sna_player = bpy.context.scene.sna_activeplayer
    op.sna_cellindex = cellindex
    op.sna_fieldindex = fieldindex


def sna_ttt_field_11148(layout_function, fieldindex, enabled, allign, fieldstatus):
    box_9E30D = layout_function.box()
    box_9E30D.alert = False
    box_9E30D.enabled = (enabled and ((fieldindex == bpy.context.scene.sna_activeboardindex) or (bpy.context.scene.sna_activeboardindex == -1)))
    box_9E30D.active = True
    box_9E30D.use_property_split = False
    box_9E30D.use_property_decorate = False
    box_9E30D.alignment = 'Expand'.upper()
    box_9E30D.scale_x = 1.0
    box_9E30D.scale_y = 1.0
    if not True: box_9E30D.operator_context = "EXEC_DEFAULT"
    col_91C04 = box_9E30D.column(heading='', align=True)
    col_91C04.alert = False
    col_91C04.enabled = True
    col_91C04.active = True
    col_91C04.use_property_split = False
    col_91C04.use_property_decorate = False
    col_91C04.scale_x = 1.0
    col_91C04.scale_y = 1.0
    col_91C04.alignment = 'Expand'.upper()
    col_91C04.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_5EFA5 = col_91C04.row(heading='', align=True)
    row_5EFA5.alert = False
    row_5EFA5.enabled = True
    row_5EFA5.active = True
    row_5EFA5.use_property_split = False
    row_5EFA5.use_property_decorate = False
    row_5EFA5.scale_x = 1.0
    row_5EFA5.scale_y = 1.0
    row_5EFA5.alignment = 'Expand'.upper()
    row_5EFA5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    layout_function = row_5EFA5
    sna_ttt_cell_074DA(layout_function, 0, fieldindex, (enabled and ((fieldindex == bpy.context.scene.sna_activeboardindex) or (bpy.context.scene.sna_activeboardindex == -1))))
    layout_function = row_5EFA5
    sna_ttt_cell_074DA(layout_function, 1, fieldindex, (enabled and ((fieldindex == bpy.context.scene.sna_activeboardindex) or (bpy.context.scene.sna_activeboardindex == -1))))
    layout_function = row_5EFA5
    sna_ttt_cell_074DA(layout_function, 2, fieldindex, (enabled and ((fieldindex == bpy.context.scene.sna_activeboardindex) or (bpy.context.scene.sna_activeboardindex == -1))))
    row_99C79 = col_91C04.row(heading='', align=True)
    row_99C79.alert = False
    row_99C79.enabled = True
    row_99C79.active = True
    row_99C79.use_property_split = False
    row_99C79.use_property_decorate = False
    row_99C79.scale_x = 1.0
    row_99C79.scale_y = 1.0
    row_99C79.alignment = 'Expand'.upper()
    row_99C79.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    layout_function = row_99C79
    sna_ttt_cell_074DA(layout_function, 3, fieldindex, (enabled and ((fieldindex == bpy.context.scene.sna_activeboardindex) or (bpy.context.scene.sna_activeboardindex == -1))))
    layout_function = row_99C79
    sna_ttt_cell_074DA(layout_function, 4, fieldindex, (enabled and ((fieldindex == bpy.context.scene.sna_activeboardindex) or (bpy.context.scene.sna_activeboardindex == -1))))
    layout_function = row_99C79
    sna_ttt_cell_074DA(layout_function, 5, fieldindex, (enabled and ((fieldindex == bpy.context.scene.sna_activeboardindex) or (bpy.context.scene.sna_activeboardindex == -1))))
    row_0570E = col_91C04.row(heading='', align=True)
    row_0570E.alert = False
    row_0570E.enabled = True
    row_0570E.active = True
    row_0570E.use_property_split = False
    row_0570E.use_property_decorate = False
    row_0570E.scale_x = 1.0
    row_0570E.scale_y = 1.0
    row_0570E.alignment = 'Expand'.upper()
    row_0570E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    layout_function = row_0570E
    sna_ttt_cell_074DA(layout_function, 6, fieldindex, (enabled and ((fieldindex == bpy.context.scene.sna_activeboardindex) or (bpy.context.scene.sna_activeboardindex == -1))))
    layout_function = row_0570E
    sna_ttt_cell_074DA(layout_function, 7, fieldindex, (enabled and ((fieldindex == bpy.context.scene.sna_activeboardindex) or (bpy.context.scene.sna_activeboardindex == -1))))
    layout_function = row_0570E
    sna_ttt_cell_074DA(layout_function, 8, fieldindex, (enabled and ((fieldindex == bpy.context.scene.sna_activeboardindex) or (bpy.context.scene.sna_activeboardindex == -1))))


class SNA_OT_Startgame_864E4(bpy.types.Operator):
    bl_idname = "sna.startgame_864e4"
    bl_label = "startGame"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        ttt_super_field['sna_superboardvalues'] = [[-1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, -1, -1, -1, -1]]
        ttt_super_field['sna_superboardallarmvalues'] = [[False, False, False, False, False, False, False, False, False], [False, False, False, False, False, False, False, False, False], [False, False, False, False, False, False, False, False, False], [False, False, False, False, False, False, False, False, False], [False, False, False, False, False, False, False, False, False], [False, False, False, False, False, False, False, False, False], [False, False, False, False, False, False, False, False, False], [False, False, False, False, False, False, False, False, False], [False, False, False, False, False, False, False, False, False]]
        ttt_super_field['sna_bordwinvalues'] = [-1, -1, -1, -1, -1, -1, -1, -1, -1]
        bpy.context.scene.sna_ingame = True
        bpy.context.scene.sna_activeboardindex = -1
        bpy.context.scene.sna_activeplayer = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_ttt_settings_7180E(layout_function, ):
    layout_function.prop(bpy.context.scene, 'sna_multiplayer', text='Multiplayer', icon_value=0, emboss=True)
    layout_function.prop(bpy.context.scene, 'sna_supermode', text='Super Mode', icon_value=0, emboss=True)
    op = layout_function.operator('sna.startgame_864e4', text='Start Game', icon_value=4, emboss=True, depress=False)
    layout_function.label(text=bpy.context.scene.sna_text, icon_value=0)


def sna_super_tttfield_B7644(layout_function, ):
    col_4AE30 = layout_function.column(heading='', align=False)
    col_4AE30.alert = False
    col_4AE30.enabled = True
    col_4AE30.active = True
    col_4AE30.use_property_split = False
    col_4AE30.use_property_decorate = False
    col_4AE30.scale_x = 1.0
    col_4AE30.scale_y = 1.0
    col_4AE30.alignment = 'Expand'.upper()
    col_4AE30.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_0DBDA = col_4AE30.row(heading='', align=False)
    row_0DBDA.alert = False
    row_0DBDA.enabled = True
    row_0DBDA.active = True
    row_0DBDA.use_property_split = False
    row_0DBDA.use_property_decorate = False
    row_0DBDA.scale_x = 1.0
    row_0DBDA.scale_y = 1.0
    row_0DBDA.alignment = 'Expand'.upper()
    row_0DBDA.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    layout_function = row_0DBDA
    sna_ttt_field_11148(layout_function, 0, (ttt_super_field['sna_bordwinvalues'][0] < 0), (not (ttt_super_field['sna_bordwinvalues'][0] < 0)), -1)
    layout_function = row_0DBDA
    sna_ttt_field_11148(layout_function, 1, (ttt_super_field['sna_bordwinvalues'][1] < 0), (not (ttt_super_field['sna_bordwinvalues'][1] < 0)), -1)
    layout_function = row_0DBDA
    sna_ttt_field_11148(layout_function, 2, (ttt_super_field['sna_bordwinvalues'][2] < 0), (not (ttt_super_field['sna_bordwinvalues'][2] < 0)), -1)
    col_4AE30.separator(factor=0.5)
    row_FCA68 = col_4AE30.row(heading='', align=False)
    row_FCA68.alert = False
    row_FCA68.enabled = True
    row_FCA68.active = True
    row_FCA68.use_property_split = False
    row_FCA68.use_property_decorate = False
    row_FCA68.scale_x = 1.0
    row_FCA68.scale_y = 1.0
    row_FCA68.alignment = 'Expand'.upper()
    row_FCA68.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    layout_function = row_FCA68
    sna_ttt_field_11148(layout_function, 3, (ttt_super_field['sna_bordwinvalues'][3] < 0), (not (ttt_super_field['sna_bordwinvalues'][3] < 0)), -1)
    layout_function = row_FCA68
    sna_ttt_field_11148(layout_function, 4, (ttt_super_field['sna_bordwinvalues'][4] < 0), (not (ttt_super_field['sna_bordwinvalues'][4] < 0)), -1)
    layout_function = row_FCA68
    sna_ttt_field_11148(layout_function, 5, (ttt_super_field['sna_bordwinvalues'][5] < 0), (not (ttt_super_field['sna_bordwinvalues'][5] < 0)), -1)
    col_4AE30.separator(factor=0.5)
    row_C5635 = col_4AE30.row(heading='', align=False)
    row_C5635.alert = False
    row_C5635.enabled = True
    row_C5635.active = True
    row_C5635.use_property_split = False
    row_C5635.use_property_decorate = False
    row_C5635.scale_x = 1.0
    row_C5635.scale_y = 1.0
    row_C5635.alignment = 'Expand'.upper()
    row_C5635.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    layout_function = row_C5635
    sna_ttt_field_11148(layout_function, 6, (ttt_super_field['sna_bordwinvalues'][6] < 0), (not (ttt_super_field['sna_bordwinvalues'][6] < 0)), -1)
    layout_function = row_C5635
    sna_ttt_field_11148(layout_function, 7, (ttt_super_field['sna_bordwinvalues'][7] < 0), (not (ttt_super_field['sna_bordwinvalues'][7] < 0)), -1)
    layout_function = row_C5635
    sna_ttt_field_11148(layout_function, 8, (ttt_super_field['sna_bordwinvalues'][8] < 0), (not (ttt_super_field['sna_bordwinvalues'][8] < 0)), -1)


class SNA_PT_ui_ttt_00BC3(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_ui_ttt_00BC3'
    bl_space_type = 'TEXT_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Tic Tac Toe'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        row_0DBA3 = layout.row(heading='', align=True)
        row_0DBA3.alert = False
        row_0DBA3.enabled = True
        row_0DBA3.active = True
        row_0DBA3.use_property_split = False
        row_0DBA3.use_property_decorate = False
        row_0DBA3.scale_x = 1.0
        row_0DBA3.scale_y = 1.0
        row_0DBA3.alignment = 'Expand'.upper()
        row_0DBA3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if bpy.context.scene.sna_ingame:
            op = row_0DBA3.operator('sna.resset_1cf71', text='', icon_value=3, emboss=True, depress=False)
            row_0DBA3.prop(bpy.context.scene, 'sna_cellsize', text='Size', icon_value=0, emboss=True)
            if ((not bpy.context.scene.sna_multiplayer) and bpy.context.scene.sna_supermode):
                op = row_0DBA3.operator('sna.bot_a0c8d', text='Random', icon_value=0, emboss=True, depress=False)
                op.sna_overwrite = True
        row_0DBA3.label(text=(' Super Tic Tac Toe' if bpy.context.scene.sna_supermode else ' Tic Tac Toe'), icon_value=0)

    def draw(self, context):
        layout = self.layout
        if bpy.context.scene.sna_ingame:
            if bpy.context.scene.sna_supermode:
                layout_function = layout
                sna_super_tttfield_B7644(layout_function, )
            else:
                layout_function = layout
                sna_ttt_field_11148(layout_function, 0, True, False, 0)
        else:
            layout_function = layout
            sna_ttt_settings_7180E(layout_function, )


class SNA_OT_Resset_1Cf71(bpy.types.Operator):
    bl_idname = "sna.resset_1cf71"
    bl_label = "resset"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_ingame = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_ingame = bpy.props.BoolProperty(name='inGame', description='', default=True)
    bpy.types.Scene.sna_activeplayer = bpy.props.BoolProperty(name='activePlayer', description='', default=False)
    bpy.types.Scene.sna_multiplayer = bpy.props.BoolProperty(name='multiPlayer', description='', default=False)
    bpy.types.Scene.sna_cellsize = bpy.props.FloatProperty(name='cellSize', description='', default=1.0, subtype='NONE', unit='NONE', min=1.0, max=5.0, step=3, precision=1)
    bpy.types.Scene.sna_activeboardindex = bpy.props.IntProperty(name='activeBoardIndex', description='', default=-1, subtype='NONE', min=-1, max=8, update=sna_update_sna_activeboardindex_A7D60)
    bpy.types.Scene.sna_supermode = bpy.props.BoolProperty(name='superMode', description='', default=False)
    bpy.types.Scene.sna_text = bpy.props.StringProperty(name='TEXT', description='', default='', subtype='NONE', maxlen=0)
    bpy.utils.register_class(SNA_OT_Bot_A0C8D)
    bpy.utils.register_class(SNA_OT_Press_C0162)
    bpy.utils.register_class(SNA_OT_Startgame_864E4)
    bpy.utils.register_class(SNA_PT_ui_ttt_00BC3)
    bpy.utils.register_class(SNA_OT_Resset_1Cf71)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_text
    del bpy.types.Scene.sna_supermode
    del bpy.types.Scene.sna_activeboardindex
    del bpy.types.Scene.sna_cellsize
    del bpy.types.Scene.sna_multiplayer
    del bpy.types.Scene.sna_activeplayer
    del bpy.types.Scene.sna_ingame
    bpy.utils.unregister_class(SNA_OT_Bot_A0C8D)
    bpy.utils.unregister_class(SNA_OT_Press_C0162)
    bpy.utils.unregister_class(SNA_OT_Startgame_864E4)
    bpy.utils.unregister_class(SNA_PT_ui_ttt_00BC3)
    bpy.utils.unregister_class(SNA_OT_Resset_1Cf71)
