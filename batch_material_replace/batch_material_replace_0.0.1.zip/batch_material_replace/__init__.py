# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Batch Material Replace",
    "author" : "Stups_Kiesel", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (0, 0, 1),
    "location" : "Object Context menu",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent


addon_keymaps = {}
_icons = None
auto_update = {'sna_selected_objs_mats': [], 'sna_blend_data_mats': [], 'sna_selected_obj_count': 0, }


def sna_object_material_replace_446EE_79FB2(Object, Old_material_name, New_material_name):
    object = Object
    old_material = Old_material_name
    new_material = New_material_name
    ob = object
    om = bpy.data.materials[old_material]
    nm = bpy.data.materials[new_material]
    # Iterate over the material slots and replace the material
    for s in ob.material_slots:
        if s.material.name == old_material:
            s.material = nm
    return


@persistent
def depsgraph_update_post_handler_7EFAA(dummy):
    auto_update['sna_blend_data_mats'] = []
    for i_16EED in range(len(bpy.data.materials)):
        if getattr(bpy.data.materials[i_16EED], 'name', None) in auto_update['sna_blend_data_mats']:
            pass
        else:
            auto_update['sna_blend_data_mats'].append(getattr(bpy.data.materials[i_16EED], 'name', None))


@persistent
def depsgraph_update_post_handler_89B3B(dummy):
    auto_update['sna_selected_objs_mats'] = []
    for i_8F512 in range(len(bpy.data.objects)):
        if bpy.data.objects[i_8F512].select_get(view_layer=bpy.context.view_layer, ):
            for i_AABDA in range(len(bpy.data.objects[i_8F512].material_slots)):
                if getattr(bpy.data.objects[i_8F512].material_slots[i_AABDA], 'name', None) in auto_update['sna_selected_objs_mats']:
                    pass
                else:
                    auto_update['sna_selected_objs_mats'].append(getattr(bpy.data.objects[i_8F512].material_slots[i_AABDA], 'name', None))


@persistent
def depsgraph_update_post_handler_F865E(dummy):
    auto_update['sna_selected_obj_count'] = 0
    for i_CCE43 in range(len(bpy.data.objects)):
        if bpy.data.objects[i_CCE43].select_get(view_layer=bpy.context.view_layer, ):
            auto_update['sna_selected_obj_count'] = int(auto_update['sna_selected_obj_count'] + 1.0)


class SNA_MT_E4B57(bpy.types.Menu):
    bl_idname = "SNA_MT_E4B57"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        layout.label(text='Select Material to replace:', icon_value=0)
        for i_DB56F in range(len(auto_update['sna_selected_objs_mats'])):
            op = layout.operator('sna.set_mat_to_replace_7a612', text=auto_update['sna_selected_objs_mats'][i_DB56F], icon_value=0, emboss=True, depress=False)
            op.sna_name = auto_update['sna_selected_objs_mats'][i_DB56F]


class SNA_MT_C7A1F(bpy.types.Menu):
    bl_idname = "SNA_MT_C7A1F"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        layout.label(text='Select Material to insert:', icon_value=0)
        for i_D5215 in range(len(auto_update['sna_blend_data_mats'])):
            op = layout.operator('sna.set_mat_to_insert_ceace', text=auto_update['sna_blend_data_mats'][i_D5215], icon_value=0, emboss=True, depress=False)
            op.sna_name = auto_update['sna_blend_data_mats'][i_D5215]


class SNA_OT_Open_Object_Material_456F5(bpy.types.Operator):
    bl_idname = "sna.open_object_material_456f5"
    bl_label = "open_object_material"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.call_menu(name="SNA_MT_E4B57")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Mat_To_Replace_7A612(bpy.types.Operator):
    bl_idname = "sna.set_mat_to_replace_7a612"
    bl_label = "set_mat_to_replace"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_name: bpy.props.StringProperty(name='name', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_mat_name_to_replace = self.sna_name
        bpy.ops.wm.call_menu(name="SNA_MT_C7A1F")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Mat_To_Insert_Ceace(bpy.types.Operator):
    bl_idname = "sna.set_mat_to_insert_ceace"
    bl_label = "set_mat_to_insert"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_name: bpy.props.StringProperty(name='name', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_mat_name_to_insert = self.sna_name
        bpy.ops.sna.replace_objs_material_1dd9f()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Replace_Objs_Material_1Dd9F(bpy.types.Operator):
    bl_idname = "sna.replace_objs_material_1dd9f"
    bl_label = "replace_objs_material"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_DA529 in range(len(bpy.data.objects)):
            result_DB69C = bpy.data.objects[i_DA529].select_get(view_layer=bpy.context.view_layer, )
            if result_DB69C:
                pass
            sna_object_material_replace_446EE_79FB2(bpy.data.objects[i_DA529], bpy.context.scene.sna_mat_name_to_replace, bpy.context.scene.sna_mat_name_to_insert)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_mt_object_context_menu_C1919(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.open_object_material_456f5', text='Objs:' + str(auto_update['sna_selected_obj_count']) + ' ' + 'Replace Material ->', icon_value=628, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_mat_name_to_replace = bpy.props.StringProperty(name='mat_name_to_replace', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_mat_name_to_insert = bpy.props.StringProperty(name='mat_name_to_insert', description='', default='', subtype='NONE', maxlen=0)
    bpy.app.handlers.depsgraph_update_post.append(depsgraph_update_post_handler_7EFAA)
    bpy.app.handlers.depsgraph_update_post.append(depsgraph_update_post_handler_89B3B)
    bpy.app.handlers.depsgraph_update_post.append(depsgraph_update_post_handler_F865E)
    bpy.utils.register_class(SNA_MT_E4B57)
    bpy.utils.register_class(SNA_MT_C7A1F)
    bpy.utils.register_class(SNA_OT_Open_Object_Material_456F5)
    bpy.utils.register_class(SNA_OT_Set_Mat_To_Replace_7A612)
    bpy.utils.register_class(SNA_OT_Set_Mat_To_Insert_Ceace)
    bpy.utils.register_class(SNA_OT_Replace_Objs_Material_1Dd9F)
    bpy.types.VIEW3D_MT_object_context_menu.append(sna_add_to_view3d_mt_object_context_menu_C1919)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_mat_name_to_insert
    del bpy.types.Scene.sna_mat_name_to_replace
    bpy.app.handlers.depsgraph_update_post.remove(depsgraph_update_post_handler_7EFAA)
    bpy.app.handlers.depsgraph_update_post.remove(depsgraph_update_post_handler_89B3B)
    bpy.app.handlers.depsgraph_update_post.remove(depsgraph_update_post_handler_F865E)
    bpy.utils.unregister_class(SNA_MT_E4B57)
    bpy.utils.unregister_class(SNA_MT_C7A1F)
    bpy.utils.unregister_class(SNA_OT_Open_Object_Material_456F5)
    bpy.utils.unregister_class(SNA_OT_Set_Mat_To_Replace_7A612)
    bpy.utils.unregister_class(SNA_OT_Set_Mat_To_Insert_Ceace)
    bpy.utils.unregister_class(SNA_OT_Replace_Objs_Material_1Dd9F)
    bpy.types.VIEW3D_MT_object_context_menu.remove(sna_add_to_view3d_mt_object_context_menu_C1919)
