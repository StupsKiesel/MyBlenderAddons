# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Z Deform",
    "author" : "Stups_Kiesel", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 1, 7),
    "location" : "3D View > N Panel",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os
import random
import bmesh
from bpy.app.handlers import persistent




def string_to_type(value, to_type, default):
    try:
        value = to_type(value)
    except:
        value = default
    return value


addon_keymaps = {}
_icons = None
create_new_mesh = {'sna_mesh_name': '', 'sna_obj': '', 'sna_coll': '', 'sna_v': [], 'sna_e': [], 'sna_f': [], }
edit_profile = {'sna_profile_to_edit': '', 'sna_value_list': [], }
interpolated_deform = {'sna_mode': 0, 'sna_quality': 0, 'sna_vertex_list': [], 'sna_edge_list': [], 'sna_vertexgroup_count': 0, 'sna_profile_count': 0, 'sna_random_number': 0, 'sna_object_to_deform': None, 'sna_interpolated_profile': [], }
nodetree = {'sna_vertex_group_index': 0, 'sna_vertex_list': [], 'sna_object': None, 'sna_new_obj_name': '', 'sna_new_collection_name': '', 'sna_verts': [], 'sna_edges': [], 'sna_faces': [], 'sna_find_closest_vertex_big': 10000000000.0, 'sna_find_closest_vertex_low': -999999995904.0, 'sna_find_temp': 0.0, 'sna_find_temp2': 9.999999944957273e+32, 'sna_find_vertex_id': 0, 'sna_vertex_cox': 0.0, 'sna_vertex_coy': 0.0, 'sna_vertexcoz': 0.0, 'sna_intersection_x': 0.0, 'sna_intersection_y': 0.0, 'sna_vertex_by_id_x': 0.0, 'sna_vertex_by_id_y': 0.0, 'sna_vertex_by_id_z': 0.0, }
object_vertex_mover = {'sna_old_x': 0.0, 'sna_old_y': 0.0, 'sna_old_z': 0.0, 'sna_new_x': 0.0, 'sna_new_y': 0.0, 'sna_new_z': 0.0, }
vertex_list_in_range = {'sna_vertex_list_in_range': [], 'sna_x_coords': [], 'sna_y_coords': [], 'sna_z_coords': [], 'sna_x_high': -9.999999843067494e+17, 'sna_x_low': 9.999999843067494e+17, 'sna_y_high': -9.999999843067494e+17, 'sna_y_low': 9.999999843067494e+17, 'sna_z_high': -9.999999843067494e+17, 'sna_z_low': 9.999999843067494e+17, }
z_deform = {'sna_deform_rofiles_var': [], 'sna_object_vertex_locations': [], 'sna_def_profile_values': [], 'sna_active_object_x_coords': [], 'sna_active_object_y_coords': [], 'sna_highest_number': -1000000000.0, 'sna_lowest_number': 1000000000.0, 'sna_highest_number_index': 0, 'sna_lowest_number_index': 0, 'sna_vertex_index_in_range': [], 'sna_vertex_current_z_coord': 0.0, 'sna_hide_panel_new_profile': True, 'sna_hide_panel_edit_profile': True, 'sna_hide_main_panel': False, 'sna_hide_panel_vg_interpolation': True, 'sna_edit_rofile': [], }
nodetree_vars_3AA6F = {'sna_path': '', }


def sna_delete_file_v2_AB1FA_3AA6F(File_Path):
    if (os.path.exists(File_Path) and (not os.path.isdir(File_Path))):
        nodetree_vars_3AA6F['sna_path'] = File_Path
        import bpy
        path = nodetree_vars_3AA6F['sna_path']
        print('Delete file -> ', path)
        os.remove(path)
        nodetree_vars_3AA6F['sna_path'] = ''


nodetree_vars_1A2F3 = {'sna_list': [], }


def sna_list_item_remove_A6378_1A2F3(List, Item_to_remove):
    nodetree_vars_1A2F3['sna_list'] = []
    for i_C921E in range(len(List)):
        if (i_C921E != Item_to_remove):
            nodetree_vars_1A2F3['sna_list'].append(List[i_C921E])
    return nodetree_vars_1A2F3['sna_list']


nodetree_vars_642F1 = {'sna_list': [], }


def sna_list_item_1down_5318F_642F1(List, Item_to_move):
    nodetree_vars_642F1['sna_list'] = []
    for i_AE66C in range(len(List)):
        if (i_AE66C < Item_to_move):
            nodetree_vars_642F1['sna_list'].append(List[i_AE66C])
        else:
            if (i_AE66C == int(Item_to_move + 1)):
                nodetree_vars_642F1['sna_list'].append(List[Item_to_move])
            else:
                if (i_AE66C == Item_to_move):
                    nodetree_vars_642F1['sna_list'].append(List[int(Item_to_move + 1)])
                else:
                    nodetree_vars_642F1['sna_list'].append(List[i_AE66C])
    return nodetree_vars_642F1['sna_list']


nodetree_vars_4AEBA = {'sna_list': [], }


def sna_list_item_1up_83D06_4AEBA(List, Item_to_move):
    nodetree_vars_4AEBA['sna_list'] = []
    for i_63FE7 in range(len(List)):
        if (i_63FE7 < int(Item_to_move - 1)):
            nodetree_vars_4AEBA['sna_list'].append(List[i_63FE7])
        else:
            if (i_63FE7 == int(Item_to_move - 1)):
                nodetree_vars_4AEBA['sna_list'].append(List[Item_to_move])
            else:
                if (i_63FE7 == Item_to_move):
                    nodetree_vars_4AEBA['sna_list'].append(List[int(Item_to_move - 1)])
                else:
                    nodetree_vars_4AEBA['sna_list'].append(List[i_63FE7])
    return nodetree_vars_4AEBA['sna_list']


def sna_update_sna_edit_index_AFEA5(self, context):
    sna_updated_prop = self.sna_edit_index
    bpy.context.scene.sna_edit_line = string_to_type(edit_profile['sna_value_list'][bpy.context.scene.sna_edit_index], float, 0)


def sna_object_details_properties_7A83A_24390(Object):
    return [Object.name, Object.type, Object.modifiers, Object.active_material, Object.material_slots, Object.vertex_groups, Object.parent, Object.children_recursive, Object.hide_get(), Object.select_get(), Object.delta_location, Object.delta_rotation_euler, Object.delta_scale, Object.dimensions, Object.location, Object.scale, Object.rotation_euler]


nodetree_vars_515A5 = {'sna_mesh_name': '', 'sna_obj_name': '', 'sna_verts': [], 'sna_edges': [], 'sna_faces': [], 'sna_coll_name': '', }


def sna_new_mesh_object_0A7EF_515A5(name_mesh, name_object, verts, edges, faces, collection_name, only_show_exampledata):
    if only_show_exampledata:
        return [[(0.0, 3.0, 0.0), (1.0, 1.0, 1.0), (2.0, 2.0, 2.0)], [(0, 1), (1, 2), (2, 0)], [(0, 1, 2)]]
    else:
        nodetree_vars_515A5['sna_mesh_name'] = name_mesh
        nodetree_vars_515A5['sna_obj_name'] = name_object
        nodetree_vars_515A5['sna_verts'] = verts
        nodetree_vars_515A5['sna_edges'] = edges
        nodetree_vars_515A5['sna_faces'] = faces
        nodetree_vars_515A5['sna_coll_name'] = collection_name
        mesh_name=nodetree_vars_515A5['sna_mesh_name']
        obj_name=nodetree_vars_515A5['sna_obj_name']
        coll_name=nodetree_vars_515A5['sna_coll_name']
        vertsData=nodetree_vars_515A5['sna_verts']
        edgesData=nodetree_vars_515A5['sna_edges']
        facesData=nodetree_vars_515A5['sna_faces']
        if mesh_name == '':
            mesh_name='new_mesh'
        if obj_name == '':
            obj_name='new_obj'
        if coll_name == '':
            coll_name='new_collection'
        # make mesh
        #vertices = [(0, 0, 0),]
        #edges = []
        #faces = []
        new_mesh = bpy.data.meshes.new(mesh_name)
        new_mesh.from_pydata(vertsData, edgesData, facesData)
        new_mesh.update()
        # make object from mesh
        new_object = bpy.data.objects.new(obj_name, new_mesh)
        # make collection
        new_collection = bpy.data.collections.new(coll_name)
        bpy.context.scene.collection.children.link(new_collection)
        # add object to scene collection
        new_collection.objects.link(new_object)
        nodetree_vars_515A5['sna_coll_name'] = ''
        nodetree_vars_515A5['sna_faces'] = []
        nodetree_vars_515A5['sna_edges'] = []
        nodetree_vars_515A5['sna_verts'] = []
        nodetree_vars_515A5['sna_obj_name'] = ''
        nodetree_vars_515A5['sna_mesh_name'] = ''
        return [[(0.0, 3.0, 0.0), (1.0, 1.0, 1.0), (2.0, 2.0, 2.0)], [(0, 1), (1, 2), (2, 0)], [(0, 1, 2)]]


def sna_object_details_properties_7A83A_6871C(Object):
    return [Object.name, Object.type, Object.modifiers, Object.active_material, Object.material_slots, Object.vertex_groups, Object.parent, Object.children_recursive, Object.hide_get(), Object.select_get(), Object.delta_location, Object.delta_rotation_euler, Object.delta_scale, Object.dimensions, Object.location, Object.scale, Object.rotation_euler]


set_active_object_vars_8BF83 = {'sna_name': '', 'sna_obj': None, }


def sna_set_active_object_by_name_11E6F_8BF83(object_name, object):
    set_active_object_vars_8BF83['sna_name'] = object_name
    set_active_object_vars_8BF83['sna_obj'] = object
    name = set_active_object_vars_8BF83['sna_name']
    obj = set_active_object_vars_8BF83['sna_obj']
    if name == '':
        bpy.ops.object.select_all(action='DESELECT') # Deselect all objects
        bpy.context.view_layer.objects.active = obj   # Make the cube the active object 
        obj.select_set(True)
    else:
        ob = bpy.context.scene.objects[name]       # Get the object
        bpy.ops.object.select_all(action='DESELECT') # Deselect all objects
        bpy.context.view_layer.objects.active = ob   # Make the cube the active object 
        ob.select_set(True)  
    set_active_object_vars_8BF83['sna_obj'] = None
    set_active_object_vars_8BF83['sna_name'] = ''
    return


def sna_modifier_subdivision_85305_258F9(level_viewport, simple, apply):
    quallity = level_viewport
    simple = simple
    apply = apply
    bpy.ops.object.modifier_add(type='SUBSURF')
    if simple == True:
        bpy.context.object.modifiers["Subdivision"].subdivision_type = 'SIMPLE'
    else:
        bpy.context.object.modifiers["Subdivision"].subdivision_type = 'CATMULL_CLARK'
    if quallity == '':
        quallity = 1
    bpy.context.object.modifiers["Subdivision"].levels = quallity
    if apply == True:
        bpy.ops.object.modifier_apply(modifier="Subdivision")
    return


set_active_object_vars_8A260 = {'sna_name': '', 'sna_obj': None, }


def sna_set_active_object_by_name_11E6F_8A260(object_name, object):
    set_active_object_vars_8A260['sna_name'] = object_name
    set_active_object_vars_8A260['sna_obj'] = object
    name = set_active_object_vars_8A260['sna_name']
    obj = set_active_object_vars_8A260['sna_obj']
    if name == '':
        bpy.ops.object.select_all(action='DESELECT') # Deselect all objects
        bpy.context.view_layer.objects.active = obj   # Make the cube the active object 
        obj.select_set(True)
    else:
        ob = bpy.context.scene.objects[name]       # Get the object
        bpy.ops.object.select_all(action='DESELECT') # Deselect all objects
        bpy.context.view_layer.objects.active = ob   # Make the cube the active object 
        ob.select_set(True)  
    set_active_object_vars_8A260['sna_obj'] = None
    set_active_object_vars_8A260['sna_name'] = ''
    return


vertex_list_in_range_vars_C6C92 = {'sna_x_high': -9.999999843067494e+17, 'sna_x_low': 9.999999843067494e+17, 'sna_y_high': -9.999999843067494e+17, 'sna_y_low': 9.999999843067494e+17, 'sna_z_high': -9.999999843067494e+17, 'sna_z_low': 9.999999843067494e+17, }


def sna_active_object_higest_lowest_vertex_values_49975_C6C92():
    vertex_list_in_range_vars_C6C92['sna_x_high'] = -9.999999843067494e+17
    vertex_list_in_range_vars_C6C92['sna_x_low'] = 9.999999843067494e+17
    vertex_list_in_range_vars_C6C92['sna_y_high'] = -9.999999843067494e+17
    vertex_list_in_range_vars_C6C92['sna_y_low'] = 9.999999843067494e+17
    vertex_list_in_range_vars_C6C92['sna_z_high'] = -9.999999843067494e+17
    vertex_list_in_range_vars_C6C92['sna_z_low'] = 9.999999843067494e+17
    for i_46F81 in range(len(bpy.context.active_object.data.vertices)):
        if (bpy.context.active_object.data.vertices[i_46F81].co[0] > vertex_list_in_range_vars_C6C92['sna_x_high']):
            vertex_list_in_range_vars_C6C92['sna_x_high'] = bpy.context.active_object.data.vertices[i_46F81].co[0]
        if (bpy.context.active_object.data.vertices[i_46F81].co[1] > vertex_list_in_range_vars_C6C92['sna_y_high']):
            vertex_list_in_range_vars_C6C92['sna_y_high'] = bpy.context.active_object.data.vertices[i_46F81].co[1]
        if (bpy.context.active_object.data.vertices[i_46F81].co[2] > vertex_list_in_range_vars_C6C92['sna_z_high']):
            vertex_list_in_range_vars_C6C92['sna_z_high'] = bpy.context.active_object.data.vertices[i_46F81].co[2]
        if (bpy.context.active_object.data.vertices[i_46F81].co[0] < vertex_list_in_range_vars_C6C92['sna_x_low']):
            vertex_list_in_range_vars_C6C92['sna_x_low'] = bpy.context.active_object.data.vertices[i_46F81].co[0]
        if (bpy.context.active_object.data.vertices[i_46F81].co[1] < vertex_list_in_range_vars_C6C92['sna_y_low']):
            vertex_list_in_range_vars_C6C92['sna_y_low'] = bpy.context.active_object.data.vertices[i_46F81].co[1]
        if (bpy.context.active_object.data.vertices[i_46F81].co[2] < vertex_list_in_range_vars_C6C92['sna_z_low']):
            vertex_list_in_range_vars_C6C92['sna_z_low'] = bpy.context.active_object.data.vertices[i_46F81].co[2]
    return [vertex_list_in_range_vars_C6C92['sna_x_high'], vertex_list_in_range_vars_C6C92['sna_x_low'], vertex_list_in_range_vars_C6C92['sna_y_high'], vertex_list_in_range_vars_C6C92['sna_y_low'], vertex_list_in_range_vars_C6C92['sna_z_high'], vertex_list_in_range_vars_C6C92['sna_z_low']]


def sna_intersection_between_2_lines_35DB0_F318E(L1_P1_XY, L1_P2_XY, L2_P1_XY, L2_P2_XY):
    L1_P1_XY = L1_P1_XY
    L1_P2_XY = L1_P2_XY
    L2_P1_XY = L2_P1_XY
    L2_P2_XY = L2_P2_XY
    intersection_point = None

    def line_intersection(line1, line2):
        xdiff = (line1[0][0] - line1[1][0], line2[0][0] - line2[1][0])
        ydiff = (line1[0][1] - line1[1][1], line2[0][1] - line2[1][1])

        def det(a, b):
            return a[0] * b[1] - a[1] * b[0]
        div = det(xdiff, ydiff)
        if div == 0:
           raise Exception('lines do not intersect')
        d = (det(*line1), det(*line2))
        x = det(d, xdiff) / div
        y = det(d, ydiff) / div
        return x, y
    # Define your lines using Vector2 input
    line1 = (L1_P1_XY, L1_P2_XY)
    line2 = (L2_P1_XY, L2_P2_XY)
    # Call the line_intersection function
    intersection_point = line_intersection(line1, line2)
    print("Intersection point:", intersection_point)
    return [intersection_point[0], intersection_point[1]]


nodetree_vars_FB99F = {'sna_vertex_list': [], 'sna_object': None, 'sna_vertex_group_index': 0, }


def sna_vertex_list_from_vertexgroup_EF01F_FB99F(Vertex_Group_Index, Object):
    nodetree_vars_FB99F['sna_vertex_list'] = []
    nodetree_vars_FB99F['sna_object'] = Object
    nodetree_vars_FB99F['sna_vertex_group_index'] = Vertex_Group_Index
    vgVerts = None
    vertex_group_index = nodetree_vars_FB99F['sna_vertex_group_index']
    o = nodetree_vars_FB99F['sna_object']
    bpy.ops.object.mode_set( mode = 'EDIT' )
    # Set the first vertex group as active:
    o.vertex_groups.active = o.vertex_groups[vertex_group_index]
    # Deselect all verts and select only current VG    
    bpy.ops.mesh.select_all( action = 'DESELECT' )
    bpy.ops.object.vertex_group_select()
    bpy.ops.object.mode_set( mode = 'OBJECT' )
    # Now the selected vertices are the ones that belong to this VG
    vgVerts = [ v.index for v in o.data.vertices if v.select ]
    nodetree_vars_FB99F['sna_vertex_list'] = nodetree_vars_FB99F['sna_vertex_list']+[vgVerts]
    print(vgVerts)
    nodetree_vars_FB99F['sna_vertex_group_index'] = 0
    nodetree_vars_FB99F['sna_object'] = None
    return vgVerts


nodetree_vars_03D2E = {'sna_delete_obj': None, 'sna_delete_obj_name': '', }


def sna_delete_object_521ED_03D2E(Object, Name):
    nodetree_vars_03D2E['sna_delete_obj'] = Object
    nodetree_vars_03D2E['sna_delete_obj_name'] = Name
    obj=nodetree_vars_03D2E['sna_delete_obj']
    obj_name=nodetree_vars_03D2E['sna_delete_obj_name']
    # Deselect all
    bpy.ops.object.select_all(action='DESELECT')
    if obj_name == '':
        obj.select_set(True)
        bpy.ops.object.delete()
    else:
        bpy.data.objects[obj_name].select_set(True) 
        bpy.ops.object.delete()  
    nodetree_vars_03D2E['sna_delete_obj'] = None
    nodetree_vars_03D2E['sna_delete_obj_name'] = ''
    return


active_object_vertex_mover_vars_94B00 = {'sna_old_x': 0.0, 'sna_old_y': 0.0, 'sna_old_z': 0.0, 'sna_new_x': 0.0, 'sna_new_y': 0.0, 'sna_new_z': 0.0, }


def sna_active_object_vertex_mover_A0331_94B00(Vertex_ID, move_X, move_Y, move_Z):
    object_vertex_mover['sna_old_x'] = 0.0
    object_vertex_mover['sna_old_y'] = 0.0
    object_vertex_mover['sna_old_z'] = 0.0
    object_vertex_mover['sna_new_x'] = 0.0
    object_vertex_mover['sna_new_y'] = 0.0
    object_vertex_mover['sna_new_z'] = 0.0
    object_vertex_mover['sna_old_x'] = bpy.context.active_object.data.vertices[Vertex_ID].co[0]
    object_vertex_mover['sna_old_y'] = bpy.context.active_object.data.vertices[Vertex_ID].co[1]
    object_vertex_mover['sna_old_z'] = bpy.context.active_object.data.vertices[Vertex_ID].co[2]
    object_vertex_mover['sna_new_x'] = float(string_to_type(move_X, float, 0) + object_vertex_mover['sna_old_x'])
    object_vertex_mover['sna_new_y'] = float(string_to_type(move_Y, float, 0) + object_vertex_mover['sna_old_y'])
    object_vertex_mover['sna_new_z'] = float(string_to_type(move_Z, float, 0) + object_vertex_mover['sna_old_z'])
    bpy.context.active_object.data.vertices[Vertex_ID].co = (object_vertex_mover['sna_new_x'], object_vertex_mover['sna_new_y'], object_vertex_mover['sna_new_z'])


set_active_object_vars_28813 = {'sna_name': '', 'sna_obj': None, }


def sna_set_active_object_by_name_11E6F_28813(object_name, object):
    set_active_object_vars_28813['sna_name'] = object_name
    set_active_object_vars_28813['sna_obj'] = object
    name = set_active_object_vars_28813['sna_name']
    obj = set_active_object_vars_28813['sna_obj']
    if name == '':
        bpy.ops.object.select_all(action='DESELECT') # Deselect all objects
        bpy.context.view_layer.objects.active = obj   # Make the cube the active object 
        obj.select_set(True)
    else:
        ob = bpy.context.scene.objects[name]       # Get the object
        bpy.ops.object.select_all(action='DESELECT') # Deselect all objects
        bpy.context.view_layer.objects.active = ob   # Make the cube the active object 
        ob.select_set(True)  
    set_active_object_vars_28813['sna_obj'] = None
    set_active_object_vars_28813['sna_name'] = ''
    return


def random_integer(min, max, seed):
    random.seed(seed)
    return random.randint(int(min), int(max))


def sna_active_object_duplicate_8F1F5_63413():
    bpy.ops.object.duplicate()


vertex_list_in_range_vars_4FA62 = {'sna_x_high': -9.999999843067494e+17, 'sna_y_high': -9.999999843067494e+17, 'sna_z_high': -9.999999843067494e+17, 'sna_x_low': 9.999999843067494e+17, 'sna_y_low': 9.999999843067494e+17, 'sna_z_low': 9.999999843067494e+17, }


def sna_active_object_higest_lowest_vertex_values_49975_4FA62():
    for i_46F81 in range(len(bpy.context.active_object.data.vertices)):
        if (bpy.context.active_object.data.vertices[i_46F81].co[0] > vertex_list_in_range_vars_4FA62['sna_x_high']):
            vertex_list_in_range_vars_4FA62['sna_x_high'] = bpy.context.active_object.data.vertices[i_46F81].co[0]
        if (bpy.context.active_object.data.vertices[i_46F81].co[1] > vertex_list_in_range_vars_4FA62['sna_y_high']):
            vertex_list_in_range_vars_4FA62['sna_y_high'] = bpy.context.active_object.data.vertices[i_46F81].co[1]
        if (bpy.context.active_object.data.vertices[i_46F81].co[2] > vertex_list_in_range_vars_4FA62['sna_z_high']):
            vertex_list_in_range_vars_4FA62['sna_z_high'] = bpy.context.active_object.data.vertices[i_46F81].co[2]
        if (bpy.context.active_object.data.vertices[i_46F81].co[0] < vertex_list_in_range_vars_4FA62['sna_x_low']):
            vertex_list_in_range_vars_4FA62['sna_x_low'] = bpy.context.active_object.data.vertices[i_46F81].co[0]
        if (bpy.context.active_object.data.vertices[i_46F81].co[1] < vertex_list_in_range_vars_4FA62['sna_y_low']):
            vertex_list_in_range_vars_4FA62['sna_y_low'] = bpy.context.active_object.data.vertices[i_46F81].co[1]
        if (bpy.context.active_object.data.vertices[i_46F81].co[2] < vertex_list_in_range_vars_4FA62['sna_z_low']):
            vertex_list_in_range_vars_4FA62['sna_z_low'] = bpy.context.active_object.data.vertices[i_46F81].co[2]
    return [vertex_list_in_range_vars_4FA62['sna_x_high'], vertex_list_in_range_vars_4FA62['sna_x_low'], vertex_list_in_range_vars_4FA62['sna_y_high'], vertex_list_in_range_vars_4FA62['sna_y_low'], vertex_list_in_range_vars_4FA62['sna_z_high'], vertex_list_in_range_vars_4FA62['sna_z_low']]


def sna_object_details_properties_7A83A_8A3BE(Object):
    return [Object.name, Object.type, Object.modifiers, Object.active_material, Object.material_slots, Object.vertex_groups, Object.parent, Object.children_recursive, Object.hide_get(), Object.select_get(), Object.delta_location, Object.delta_rotation_euler, Object.delta_scale, Object.dimensions, Object.location, Object.scale, Object.rotation_euler]


nodetree_vars_BFEC8 = {'sna_vertex_list': [], 'sna_object': None, 'sna_vertex_group_index': 0, }


def sna_vertex_list_from_vertexgroup_EF01F_BFEC8(Vertex_Group_Index, Object):
    nodetree_vars_BFEC8['sna_vertex_list'] = []
    nodetree_vars_BFEC8['sna_object'] = Object
    nodetree_vars_BFEC8['sna_vertex_group_index'] = Vertex_Group_Index
    vgVerts = None
    vertex_group_index = nodetree_vars_BFEC8['sna_vertex_group_index']
    o = nodetree_vars_BFEC8['sna_object']
    bpy.ops.object.mode_set( mode = 'EDIT' )
    # Set the first vertex group as active:
    o.vertex_groups.active = o.vertex_groups[vertex_group_index]
    # Deselect all verts and select only current VG    
    bpy.ops.mesh.select_all( action = 'DESELECT' )
    bpy.ops.object.vertex_group_select()
    bpy.ops.object.mode_set( mode = 'OBJECT' )
    # Now the selected vertices are the ones that belong to this VG
    vgVerts = [ v.index for v in o.data.vertices if v.select ]
    nodetree_vars_BFEC8['sna_vertex_list'] = nodetree_vars_BFEC8['sna_vertex_list']+[vgVerts]
    print(vgVerts)
    nodetree_vars_BFEC8['sna_vertex_group_index'] = 0
    nodetree_vars_BFEC8['sna_object'] = None
    return vgVerts


def sna_blender_appdata_path_22557_F2E82():
    blenderappdata_path = None
    user_path = bpy.utils.resource_path('USER')
    blenderappdata_path = user_path
    return [blenderappdata_path, blenderappdata_path + '\\config', blenderappdata_path + '\\scripts\\addons']


def sna_string_all_lowercase_3D9E1_65DB2(StRiNg):
    return StRiNg.replace('A', 'a').replace('B', 'b').replace('C', 'c').replace('D', 'd').replace('E', 'e').replace('F', 'f').replace('G', 'g').replace('H', 'h').replace('I', 'i').replace('J', 'j').replace('K', 'k').replace('L', 'l').replace('M', 'm').replace('N', 'n').replace('O', 'o').replace('P', 'p').replace('Q', 'q').replace('R', 'r').replace('S', 's').replace('T', 't').replace('U', 'u').replace('V', 'v').replace('W', 'w').replace('X', 'x').replace('Y', 'y').replace('Z', 'z')


vertex_list_in_range_vars_829A6 = {'sna_x_high': -9.999999843067494e+17, 'sna_x_low': 9.999999843067494e+17, 'sna_y_high': -9.999999843067494e+17, 'sna_y_low': 9.999999843067494e+17, 'sna_z_high': -9.999999843067494e+17, 'sna_z_low': 9.999999843067494e+17, }


def sna_active_object_higest_lowest_vertex_values_49975_829A6():
    vertex_list_in_range_vars_829A6['sna_x_high'] = -9.999999843067494e+17
    vertex_list_in_range_vars_829A6['sna_x_low'] = 9.999999843067494e+17
    vertex_list_in_range_vars_829A6['sna_y_high'] = -9.999999843067494e+17
    vertex_list_in_range_vars_829A6['sna_y_low'] = 9.999999843067494e+17
    vertex_list_in_range_vars_829A6['sna_z_high'] = -9.999999843067494e+17
    vertex_list_in_range_vars_829A6['sna_z_low'] = 9.999999843067494e+17
    for i_46F81 in range(len(bpy.context.active_object.data.vertices)):
        if (bpy.context.active_object.data.vertices[i_46F81].co[0] > vertex_list_in_range_vars_829A6['sna_x_high']):
            vertex_list_in_range_vars_829A6['sna_x_high'] = bpy.context.active_object.data.vertices[i_46F81].co[0]
        if (bpy.context.active_object.data.vertices[i_46F81].co[1] > vertex_list_in_range_vars_829A6['sna_y_high']):
            vertex_list_in_range_vars_829A6['sna_y_high'] = bpy.context.active_object.data.vertices[i_46F81].co[1]
        if (bpy.context.active_object.data.vertices[i_46F81].co[2] > vertex_list_in_range_vars_829A6['sna_z_high']):
            vertex_list_in_range_vars_829A6['sna_z_high'] = bpy.context.active_object.data.vertices[i_46F81].co[2]
        if (bpy.context.active_object.data.vertices[i_46F81].co[0] < vertex_list_in_range_vars_829A6['sna_x_low']):
            vertex_list_in_range_vars_829A6['sna_x_low'] = bpy.context.active_object.data.vertices[i_46F81].co[0]
        if (bpy.context.active_object.data.vertices[i_46F81].co[1] < vertex_list_in_range_vars_829A6['sna_y_low']):
            vertex_list_in_range_vars_829A6['sna_y_low'] = bpy.context.active_object.data.vertices[i_46F81].co[1]
        if (bpy.context.active_object.data.vertices[i_46F81].co[2] < vertex_list_in_range_vars_829A6['sna_z_low']):
            vertex_list_in_range_vars_829A6['sna_z_low'] = bpy.context.active_object.data.vertices[i_46F81].co[2]
    return [vertex_list_in_range_vars_829A6['sna_x_high'], vertex_list_in_range_vars_829A6['sna_x_low'], vertex_list_in_range_vars_829A6['sna_y_high'], vertex_list_in_range_vars_829A6['sna_y_low'], vertex_list_in_range_vars_829A6['sna_z_high'], vertex_list_in_range_vars_829A6['sna_z_low']]


vertex_list_in_range_vars_EF1F5 = {'sna_vertex_list_in_range': [], }


def sna_get_affected_vertex_index_list_v2_EB1A2_EF1F5(Step_lenth, current_itteration, Highest_Value, Lowest_Value, Axis, direction_plus_miinus, Tollerance):
    vertex_list_in_range_vars_EF1F5['sna_vertex_list_in_range'] = []
    for i_0398A in range(len(bpy.context.active_object.data.vertices)):
        if ((float(float((Highest_Value if (direction_plus_miinus == '-') else Lowest_Value) + Tollerance) + (float(0.0 - float(Step_lenth * current_itteration)) if (direction_plus_miinus == '-') else float(Step_lenth * current_itteration))) >= (bpy.context.active_object.data.vertices[i_0398A].co[1] if (Axis == 'y') else bpy.context.active_object.data.vertices[i_0398A].co[0])) and (float(float((Highest_Value if (direction_plus_miinus == '-') else Lowest_Value) - Tollerance) + (float(0.0 - float(Step_lenth * current_itteration)) if (direction_plus_miinus == '-') else float(Step_lenth * current_itteration))) <= (bpy.context.active_object.data.vertices[i_0398A].co[1] if (Axis == 'y') else bpy.context.active_object.data.vertices[i_0398A].co[0]))):
            vertex_list_in_range_vars_EF1F5['sna_vertex_list_in_range'].append(i_0398A)
    return vertex_list_in_range_vars_EF1F5['sna_vertex_list_in_range']


nodetree_vars_14C79 = {'sna_path': '', }


def sna_delete_file_v2_AB1FA_14C79(File_Path):
    if (os.path.exists(File_Path) and (not os.path.isdir(File_Path))):
        nodetree_vars_14C79['sna_path'] = File_Path
        import bpy
        path = nodetree_vars_14C79['sna_path']
        print('Delete file -> ', path)
        os.remove(path)
        nodetree_vars_14C79['sna_path'] = ''


def load_preview_icon(path):
    global _icons
    if not path in _icons:
        if os.path.exists(path):
            _icons.load(path, path, "IMAGE")
        else:
            return 0
    return _icons[path].icon_id


class SNA_OT_Cancle_Edit_66Fb5(bpy.types.Operator):
    bl_idname = "sna.cancle_edit_66fb5"
    bl_label = "cancle_edit"
    bl_description = "Cancle"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        edit_profile['sna_profile_to_edit'] = ''
        z_deform['sna_hide_main_panel'] = False
        z_deform['sna_hide_panel_new_profile'] = True
        z_deform['sna_hide_panel_edit_profile'] = True
        z_deform['sna_hide_panel_vg_interpolation'] = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Load_Profile_To_Edit_3Ed65(bpy.types.Operator):
    bl_idname = "sna.load_profile_to_edit_3ed65"
    bl_label = "load profile to edit"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        text_39B78 = ""
        lines_39B78 = []
        if os.path.exists(os.path.join(bpy.context.scene.sna_folder_path,bpy.context.scene.sna_selected_deform_frofile + '.txt')):
            with open(os.path.join(bpy.context.scene.sna_folder_path,bpy.context.scene.sna_selected_deform_frofile + '.txt'), "r") as file_39B78:
                lines_39B78 = list(map(lambda l: l.strip(), file_39B78.readlines()))
                text_39B78 = "\n".join(lines_39B78)
        z_deform['sna_hide_panel_edit_profile'] = False
        edit_profile['sna_value_list'] = lines_39B78
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Save_Edited_Profile_E9009(bpy.types.Operator):
    bl_idname = "sna.save_edited_profile_e9009"
    bl_label = "save_edited_profile"
    bl_description = "Save"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_delete_file_v2_AB1FA_3AA6F(os.path.join(bpy.context.scene.sna_folder_path,bpy.context.scene.sna_selected_deform_frofile + '.txt'))
        for i_4F0E7 in range(len(edit_profile['sna_value_list'])):
            with open(os.path.join(bpy.context.scene.sna_folder_path,bpy.context.scene.sna_selected_deform_frofile + '.txt'), mode='a') as file_8B093:
                file_8B093.write(edit_profile['sna_value_list'][i_4F0E7] + '\n')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_Cab85(bpy.types.Operator):
    bl_idname = "sna.remove_cab85"
    bl_label = "remove"
    bl_description = "Remove"
    bl_options = {"REGISTER", "UNDO"}
    sna_index: bpy.props.IntProperty(name='index', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        list_0_1a2f3 = sna_list_item_remove_A6378_1A2F3(edit_profile['sna_value_list'], self.sna_index)
        edit_profile['sna_value_list'] = list_0_1a2f3
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Move_Down_96399(bpy.types.Operator):
    bl_idname = "sna.move_down_96399"
    bl_label = "move_down"
    bl_description = "Move down"
    bl_options = {"REGISTER", "UNDO"}
    sna_index: bpy.props.IntProperty(name='index', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        list_0_642f1 = sna_list_item_1down_5318F_642F1(edit_profile['sna_value_list'], self.sna_index)
        edit_profile['sna_value_list'] = list_0_642f1
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Move_Up_33Ba5(bpy.types.Operator):
    bl_idname = "sna.move_up_33ba5"
    bl_label = "move_up"
    bl_description = "Move up"
    bl_options = {"REGISTER", "UNDO"}
    sna_index: bpy.props.IntProperty(name='index', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        list_0_4aeba = sna_list_item_1up_83D06_4AEBA(edit_profile['sna_value_list'], self.sna_index)
        edit_profile['sna_value_list'] = list_0_4aeba
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Edit_Index_Dfdda(bpy.types.Operator):
    bl_idname = "sna.edit_index_dfdda"
    bl_label = "edit_index"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_value: bpy.props.IntProperty(name='value', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_edit_index = self.sna_value
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Save_Edit_Line_8A2D7(bpy.types.Operator):
    bl_idname = "sna.save_edit_line_8a2d7"
    bl_label = "save_edit_line"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        edit_profile['sna_value_list'].extend(bpy.context.scene.sna_edit_line)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Mode_4E10A(bpy.types.Operator):
    bl_idname = "sna.set_mode_4e10a"
    bl_label = "set mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_mode: bpy.props.IntProperty(name='mode', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        interpolated_deform['sna_mode'] = self.sna_mode
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Quallity_3D1C4(bpy.types.Operator):
    bl_idname = "sna.set_quallity_3d1c4"
    bl_label = "set quallity"
    bl_description = "Interpolations quallity"
    bl_options = {"REGISTER", "UNDO"}
    sna_quallity: bpy.props.IntProperty(name='quallity', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        interpolated_deform['sna_quality'] = self.sna_quallity
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Interpolated_Deform_Run_049Ba(bpy.types.Operator):
    bl_idname = "sna.interpolated_deform_run_049ba"
    bl_label = "Interpolated_deform_run"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        interpolated_deform['sna_object_to_deform'] = bpy.context.active_object
        if (0 == interpolated_deform['sna_mode']):
            text_9DBE5 = ""
            lines_9DBE5 = []
            if os.path.exists(os.path.join(bpy.context.scene.sna_folder_path,bpy.context.scene.sna_selected_deform_frofile + '.txt')):
                with open(os.path.join(bpy.context.scene.sna_folder_path,bpy.context.scene.sna_selected_deform_frofile + '.txt'), "r") as file_9DBE5:
                    lines_9DBE5 = list(map(lambda l: l.strip(), file_9DBE5.readlines()))
                    text_9DBE5 = "\n".join(lines_9DBE5)
            interpolated_deform['sna_vertexgroup_count'] = len(sna_object_details_properties_7A83A_24390(bpy.context.view_layer.objects.active)[5])
            interpolated_deform['sna_profile_count'] = len(lines_9DBE5)
            for i_25DE2 in range(len(lines_9DBE5)):
                interpolated_deform['sna_vertex_list'].append((float(i_25DE2 + 0.0), 0.0, round(float(string_to_type(lines_9DBE5[i_25DE2], float, 0) + 0.0), abs(6))))
                if (i_25DE2 >= 1):
                    interpolated_deform['sna_edge_list'].append((int(i_25DE2 - 1), i_25DE2))
            bpy.ops.sna.make_random_int_ac6ca('INVOKE_DEFAULT', )
            example_verts_0_515a5, example_edges_1_515a5, example_faces_2_515a5 = sna_new_mesh_object_0A7EF_515A5(sna_object_details_properties_7A83A_6871C(bpy.context.view_layer.objects.active)[0] + 'sna_deform_profil_calc_obj' + str(interpolated_deform['sna_random_number']), sna_object_details_properties_7A83A_6871C(bpy.context.view_layer.objects.active)[0] + 'sna_deform_profil_calc_obj' + str(interpolated_deform['sna_random_number']), interpolated_deform['sna_vertex_list'], interpolated_deform['sna_edge_list'], [], sna_object_details_properties_7A83A_6871C(bpy.context.view_layer.objects.active)[0] + 'sna_deform_profil_calc_obj' + str(interpolated_deform['sna_random_number']), False)
            interpolated_deform['sna_vertex_list'] = []
            interpolated_deform['sna_edge_list'] = []
            sna_set_active_object_by_name_11E6F_8BF83(sna_object_details_properties_7A83A_6871C(bpy.context.view_layer.objects.active)[0] + 'sna_deform_profil_calc_obj' + str(interpolated_deform['sna_random_number']), None)
            sna_modifier_subdivision_85305_258F9(interpolated_deform['sna_quality'], False, True)
            for i_3D0F8 in range(interpolated_deform['sna_vertexgroup_count']):
                closest_bigger_0_d3846, closest_lower_1_d3846 = sna_find_closest_vertex_in_x_9D3C6(round(float(i_3D0F8 * float(float(interpolated_deform['sna_profile_count'] - 1.0) / interpolated_deform['sna_vertexgroup_count'])), abs(5)), bpy.context.view_layer.objects.active)
                vertex_id_0_7471b = sna_find_vertex_id__991C7(closest_bigger_0_d3846, bpy.context.view_layer.objects.active)
                vertex_id_0_cf583 = sna_find_vertex_id__991C7(closest_lower_1_d3846, bpy.context.view_layer.objects.active)
                x_highest_0_c6c92, x_lowest_1_c6c92, y_highest_2_c6c92, y_lowest_3_c6c92, z_highest_4_c6c92, z_lowest_5_c6c92 = sna_active_object_higest_lowest_vertex_values_49975_C6C92()
                interpolated_deform['sna_interpolated_profile'].append(sna_intersection_between_2_lines_35DB0_F318E((bpy.context.active_object.data.vertices[vertex_id_0_7471b].co[0], bpy.context.active_object.data.vertices[vertex_id_0_7471b].co[2]), (bpy.context.active_object.data.vertices[vertex_id_0_cf583].co[0], bpy.context.active_object.data.vertices[vertex_id_0_cf583].co[2]), (float(i_3D0F8 * float(float(interpolated_deform['sna_profile_count'] - 1.0) / interpolated_deform['sna_vertexgroup_count'])), float(z_highest_4_c6c92 + 1.0)), (float(i_3D0F8 * float(float(interpolated_deform['sna_profile_count'] - 1.0) / interpolated_deform['sna_vertexgroup_count'])), float(z_lowest_5_c6c92 - 1.0)))[1])
            sna_set_active_object_by_name_11E6F_8A260('', interpolated_deform['sna_object_to_deform'])
            for i_35E96 in range(len(interpolated_deform['sna_interpolated_profile'])):
                vertex_list_0_fb99f = sna_vertex_list_from_vertexgroup_EF01F_FB99F(i_35E96, bpy.context.view_layer.objects.active)
                for i_C220A in range(len(vertex_list_0_fb99f)):
                    sna_active_object_vertex_mover_A0331_94B00(vertex_list_0_fb99f[i_C220A], '', '', str(interpolated_deform['sna_interpolated_profile'][i_35E96]))
            sna_delete_object_521ED_03D2E(bpy.context.view_layer.objects.active, sna_object_details_properties_7A83A_6871C(bpy.context.view_layer.objects.active)[0] + 'sna_deform_profil_calc_obj' + str(interpolated_deform['sna_random_number']))
            sna_set_active_object_by_name_11E6F_28813('', interpolated_deform['sna_object_to_deform'])
            interpolated_deform['sna_interpolated_profile'] = []
            interpolated_deform['sna_object_to_deform'] = None
            interpolated_deform['sna_edge_list'] = []
            interpolated_deform['sna_vertex_list'] = []
        if (1 == interpolated_deform['sna_mode']):
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Make_Random_Int_Ac6Ca(bpy.types.Operator):
    bl_idname = "sna.make_random_int_ac6ca"
    bl_label = "make random int"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        interpolated_deform['sna_random_number'] = random_integer(0.0, 999.0, None)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_vertex_list_from_vertexgroup_EF01F(Vertex_Group_Index, Object):
    nodetree['sna_vertex_list'] = []
    nodetree['sna_object'] = Object
    nodetree['sna_vertex_group_index'] = Vertex_Group_Index
    vgVerts = None
    vertex_group_index = nodetree['sna_vertex_group_index']
    o = nodetree['sna_object']
    bpy.ops.object.mode_set( mode = 'EDIT' )
    # Set the first vertex group as active:
    o.vertex_groups.active = o.vertex_groups[vertex_group_index]
    # Deselect all verts and select only current VG    
    bpy.ops.mesh.select_all( action = 'DESELECT' )
    bpy.ops.object.vertex_group_select()
    bpy.ops.object.mode_set( mode = 'OBJECT' )
    # Now the selected vertices are the ones that belong to this VG
    vgVerts = [ v.index for v in o.data.vertices if v.select ]
    nodetree['sna_vertex_list'] = nodetree['sna_vertex_list']+[vgVerts]
    print(vgVerts)
    nodetree['sna_vertex_group_index'] = 0
    nodetree['sna_object'] = None
    return vgVerts


def sna_intersection_between_2_lines_35DB0(L1_P1_XY, L1_P2_XY, L2_P1_XY, L2_P2_XY):
    L1_P1_XY = L1_P1_XY
    L1_P2_XY = L1_P2_XY
    L2_P1_XY = L2_P1_XY
    L2_P2_XY = L2_P2_XY
    intersection_point = None

    def line_intersection(line1, line2):
        xdiff = (line1[0][0] - line1[1][0], line2[0][0] - line2[1][0])
        ydiff = (line1[0][1] - line1[1][1], line2[0][1] - line2[1][1])

        def det(a, b):
            return a[0] * b[1] - a[1] * b[0]
        div = det(xdiff, ydiff)
        if div == 0:
           raise Exception('lines do not intersect')
        d = (det(*line1), det(*line2))
        x = det(d, xdiff) / div
        y = det(d, ydiff) / div
        return x, y
    # Define your lines using Vector2 input
    line1 = (L1_P1_XY, L1_P2_XY)
    line2 = (L2_P1_XY, L2_P2_XY)
    # Call the line_intersection function
    intersection_point = line_intersection(line1, line2)
    print("Intersection point:", intersection_point)
    return [intersection_point[0], intersection_point[1]]


def sna_find_vertex_id__991C7(x_value, Object):
    nodetree['sna_find_vertex_id'] = 0
    bm_E0B7F = bmesh.new()
    if Object:
        if Object.mode == 'EDIT' and False:
            bm_E0B7F = bmesh.from_edit_mesh(Object.data)
        else:
            if False:
                dg = bpy.context.evaluated_depsgraph_get()
                bm_E0B7F.from_mesh(Object.evaluated_get(dg).to_mesh())
            else:
                bm_E0B7F.from_mesh(Object.data)
    if True:
        bm_E0B7F.transform(Object.matrix_world)
    bm_E0B7F.verts.ensure_lookup_table()
    bm_E0B7F.faces.ensure_lookup_table()
    bm_E0B7F.edges.ensure_lookup_table()
    for i_6CE45 in range(len(bm_E0B7F.verts)):
        if (bm_E0B7F.verts[i_6CE45].co[0] == x_value):
            nodetree['sna_find_vertex_id'] = bm_E0B7F.verts[i_6CE45].index
    return nodetree['sna_find_vertex_id']


def sna_find_closest_vertex_in_x_9D3C6(value, Object):
    nodetree['sna_find_closest_vertex_big'] = 10000000000.0
    nodetree['sna_find_closest_vertex_low'] = -999999995904.0
    bm_EF0F6 = bmesh.new()
    if Object:
        if Object.mode == 'EDIT' and True:
            bm_EF0F6 = bmesh.from_edit_mesh(Object.data)
        else:
            if False:
                dg = bpy.context.evaluated_depsgraph_get()
                bm_EF0F6.from_mesh(Object.evaluated_get(dg).to_mesh())
            else:
                bm_EF0F6.from_mesh(Object.data)
    if True:
        bm_EF0F6.transform(Object.matrix_world)
    bm_EF0F6.verts.ensure_lookup_table()
    bm_EF0F6.faces.ensure_lookup_table()
    bm_EF0F6.edges.ensure_lookup_table()
    for i_C4088 in range(len(bm_EF0F6.verts)):
        if ((bm_EF0F6.verts[i_C4088].co[0] < round(value, abs(4))) and (bm_EF0F6.verts[i_C4088].co[0] > nodetree['sna_find_temp'])):
            nodetree['sna_find_temp'] = bm_EF0F6.verts[i_C4088].co[0]
    nodetree['sna_find_closest_vertex_low'] = nodetree['sna_find_temp']
    nodetree['sna_find_temp'] = 0.0
    for i_782B1 in range(len(bm_EF0F6.verts)):
        if ((bm_EF0F6.verts[i_782B1].co[0] > round(value, abs(4))) and (bm_EF0F6.verts[i_782B1].co[0] < nodetree['sna_find_temp2'])):
            nodetree['sna_find_temp2'] = bm_EF0F6.verts[i_782B1].co[0]
    nodetree['sna_find_closest_vertex_big'] = nodetree['sna_find_temp2']
    nodetree['sna_find_temp2'] = 9.999999944957273e+32
    return [nodetree['sna_find_closest_vertex_big'], nodetree['sna_find_closest_vertex_low']]


def sna_object_vertex_mover_A0331(Vertex_ID, move_X, move_Y, move_Z):
    object_vertex_mover['sna_old_x'] = 0.0
    object_vertex_mover['sna_old_y'] = 0.0
    object_vertex_mover['sna_old_z'] = 0.0
    object_vertex_mover['sna_new_x'] = 0.0
    object_vertex_mover['sna_new_y'] = 0.0
    object_vertex_mover['sna_new_z'] = 0.0
    object_vertex_mover['sna_old_x'] = bpy.context.object.data.vertices[Vertex_ID].co[0]
    object_vertex_mover['sna_old_y'] = bpy.context.object.data.vertices[Vertex_ID].co[1]
    object_vertex_mover['sna_old_z'] = bpy.context.object.data.vertices[Vertex_ID].co[2]
    object_vertex_mover['sna_new_x'] = float(string_to_type(move_X, float, 0) + object_vertex_mover['sna_old_x'])
    object_vertex_mover['sna_new_y'] = float(string_to_type(move_Y, float, 0) + object_vertex_mover['sna_old_y'])
    object_vertex_mover['sna_new_z'] = float(string_to_type(move_Z, float, 0) + object_vertex_mover['sna_old_z'])
    bpy.context.object.data.vertices[Vertex_ID].co = (object_vertex_mover['sna_new_x'], object_vertex_mover['sna_new_y'], object_vertex_mover['sna_new_z'])


def sna_get_affected_vertex_index_list_v2_EB1A2(Step_lenth, current_itteration, Highest_Value, Lowest_Value, Axis, direction_plus_miinus, Tollerance):
    vertex_list_in_range['sna_vertex_list_in_range'] = []
    for i_0398A in range(len(bpy.context.active_object.data.vertices)):
        if ((float(float((Highest_Value if (direction_plus_miinus == '-') else Lowest_Value) + Tollerance) + (float(0.0 - float(Step_lenth * current_itteration)) if (direction_plus_miinus == '-') else float(Step_lenth * current_itteration))) >= (bpy.context.active_object.data.vertices[i_0398A].co[1] if (Axis == 'y') else bpy.context.active_object.data.vertices[i_0398A].co[0])) and (float(float((Highest_Value if (direction_plus_miinus == '-') else Lowest_Value) - Tollerance) + (float(0.0 - float(Step_lenth * current_itteration)) if (direction_plus_miinus == '-') else float(Step_lenth * current_itteration))) <= (bpy.context.active_object.data.vertices[i_0398A].co[1] if (Axis == 'y') else bpy.context.active_object.data.vertices[i_0398A].co[0]))):
            vertex_list_in_range['sna_vertex_list_in_range'].append(i_0398A)
    return vertex_list_in_range['sna_vertex_list_in_range']


def sna_active_object_higest_lowest_vertex_values_49975():
    vertex_list_in_range['sna_x_high'] = -9.999999843067494e+17
    vertex_list_in_range['sna_x_low'] = 9.999999843067494e+17
    vertex_list_in_range['sna_y_high'] = -9.999999843067494e+17
    vertex_list_in_range['sna_y_low'] = 9.999999843067494e+17
    vertex_list_in_range['sna_z_high'] = -9.999999843067494e+17
    vertex_list_in_range['sna_z_low'] = 9.999999843067494e+17
    for i_46F81 in range(len(bpy.context.active_object.data.vertices)):
        if (bpy.context.active_object.data.vertices[i_46F81].co[0] > vertex_list_in_range['sna_x_high']):
            vertex_list_in_range['sna_x_high'] = bpy.context.active_object.data.vertices[i_46F81].co[0]
        if (bpy.context.active_object.data.vertices[i_46F81].co[1] > vertex_list_in_range['sna_y_high']):
            vertex_list_in_range['sna_y_high'] = bpy.context.active_object.data.vertices[i_46F81].co[1]
        if (bpy.context.active_object.data.vertices[i_46F81].co[2] > vertex_list_in_range['sna_z_high']):
            vertex_list_in_range['sna_z_high'] = bpy.context.active_object.data.vertices[i_46F81].co[2]
        if (bpy.context.active_object.data.vertices[i_46F81].co[0] < vertex_list_in_range['sna_x_low']):
            vertex_list_in_range['sna_x_low'] = bpy.context.active_object.data.vertices[i_46F81].co[0]
        if (bpy.context.active_object.data.vertices[i_46F81].co[1] < vertex_list_in_range['sna_y_low']):
            vertex_list_in_range['sna_y_low'] = bpy.context.active_object.data.vertices[i_46F81].co[1]
        if (bpy.context.active_object.data.vertices[i_46F81].co[2] < vertex_list_in_range['sna_z_low']):
            vertex_list_in_range['sna_z_low'] = bpy.context.active_object.data.vertices[i_46F81].co[2]
    return [vertex_list_in_range['sna_x_high'], vertex_list_in_range['sna_x_low'], vertex_list_in_range['sna_y_high'], vertex_list_in_range['sna_y_low'], vertex_list_in_range['sna_z_high'], vertex_list_in_range['sna_z_low']]


class SNA_PT_Z_DEFORM_D14C9(bpy.types.Panel):
    bl_label = 'Z deform'
    bl_idname = 'SNA_PT_Z_DEFORM_D14C9'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Stups_Kiesel'
    bl_order = 6
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not 'OBJECT'==bpy.context.mode))

    def draw_header(self, context):
        layout = self.layout
        row_CF079 = layout.row(heading='', align=True)
        row_CF079.alert = False
        row_CF079.enabled = True
        row_CF079.active = True
        row_CF079.use_property_split = False
        row_CF079.use_property_decorate = False
        row_CF079.scale_x = 1.0
        row_CF079.scale_y = 1.0
        row_CF079.alignment = 'Expand'.upper()
        if not True: row_CF079.operator_context = "EXEC_DEFAULT"
        op = row_CF079.operator('sna.load_folder_d8907', text='', icon_value=692, emboss=True, depress=False)
        op = row_CF079.operator('sna.toggle_new_profile_panel_182d2', text='', icon_value=216, emboss=True, depress=(not z_deform['sna_hide_panel_new_profile']))
        row_CF079.label(text='v' + str((1, 1, 7)[0]) + '.' + str((1, 1, 7)[1]) + '.' + str((1, 1, 7)[2]), icon_value=0)

    def draw(self, context):
        layout = self.layout


class SNA_OT_Run_Hight_Deform_53233(bpy.types.Operator):
    bl_idname = "sna.run_hight_deform_53233"
    bl_label = "run_hight_deform"
    bl_description = "start deformation process"
    bl_options = {"REGISTER", "UNDO"}
    sna_axis: bpy.props.StringProperty(name='axis', description='', default='', subtype='NONE', maxlen=0)
    sna_direction: bpy.props.StringProperty(name='direction', description='', default='', subtype='NONE', maxlen=0)
    sna_duplicate: bpy.props.BoolProperty(name='duplicate', description='', default=False)
    sna_step_over: bpy.props.FloatProperty(name='step_over', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=6)
    sna_tollerance: bpy.props.FloatProperty(name='tollerance', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=6)
    sna_deform_profile: bpy.props.StringProperty(name='deform_profile', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Select deform profile befor execution!')
        return not ('' == bpy.context.scene.sna_selected_deform_frofile)

    def execute(self, context):
        z_deform['sna_def_profile_values'] = []
        z_deform['sna_object_vertex_locations'] = []
        z_deform['sna_active_object_x_coords'] = []
        z_deform['sna_active_object_y_coords'] = []
        z_deform['sna_highest_number'] = -1000000000.0
        z_deform['sna_highest_number_index'] = 0
        z_deform['sna_lowest_number'] = 1000000000.0
        z_deform['sna_lowest_number_index'] = 0
        z_deform['sna_def_profile_values'] = []
        text_B19E8 = ""
        lines_B19E8 = []
        if os.path.exists(bpy.context.scene.sna_folder_path + '\\' + bpy.context.scene.sna_selected_deform_frofile + '.txt'):
            with open(bpy.context.scene.sna_folder_path + '\\' + bpy.context.scene.sna_selected_deform_frofile + '.txt', "r") as file_B19E8:
                lines_B19E8 = list(map(lambda l: l.strip(), file_B19E8.readlines()))
                text_B19E8 = "\n".join(lines_B19E8)
        for i_6CE2D in range(len(lines_B19E8)):
            z_deform['sna_def_profile_values'].append(lines_B19E8[i_6CE2D])
        if bpy.context.scene.sna_duplicate:
            sna_active_object_duplicate_8F1F5_63413()
        if bpy.context.scene.sna_vertexgroup_mode:
            if (len(sna_object_details_properties_7A83A_8A3BE(bpy.context.view_layer.objects.active)[5]) == len(z_deform['sna_def_profile_values'])):
                for i_738AD in range(len(sna_object_details_properties_7A83A_8A3BE(bpy.context.view_layer.objects.active)[5])):
                    vertex_list_0_bfec8 = sna_vertex_list_from_vertexgroup_EF01F_BFEC8(i_738AD, bpy.context.view_layer.objects.active)
                    for i_F0D2A in range(len(vertex_list_0_bfec8)):
                        sna_object_vertex_mover_A0331(vertex_list_0_bfec8[i_F0D2A], '', '', z_deform['sna_def_profile_values'][i_738AD])
            else:
                z_deform['sna_hide_main_panel'] = True
                z_deform['sna_hide_panel_new_profile'] = True
                z_deform['sna_hide_panel_edit_profile'] = True
                z_deform['sna_hide_panel_vg_interpolation'] = False
        else:
            x_highest_0_4fa62, x_lowest_1_4fa62, y_highest_2_4fa62, y_lowest_3_4fa62, z_highest_4_4fa62, z_lowest_5_4fa62 = sna_active_object_higest_lowest_vertex_values_49975_4FA62()
            for i_8191E in range(len(z_deform['sna_def_profile_values'])):
                vertex_index_in_range_0_a3775 = sna_get_affected_vertex_index_list_v2_EB1A2(bpy.context.scene.sna_step_over, i_8191E, (y_highest_2_4fa62 if (bpy.context.scene.sna_axis == 'y') else x_highest_0_4fa62), (y_lowest_3_4fa62 if (bpy.context.scene.sna_axis == 'y') else x_lowest_1_4fa62), bpy.context.scene.sna_axis, bpy.context.scene.sna_direction, bpy.context.scene.sna_tollerance)
                for i_5CEC2 in range(len(vertex_index_in_range_0_a3775)):
                    sna_object_vertex_mover_A0331(vertex_index_in_range_0_a3775[i_5CEC2], '', '', str(z_deform['sna_def_profile_values'][i_8191E]))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Load_Folder_D8907(bpy.types.Operator):
    bl_idname = "sna.load_folder_d8907"
    bl_label = "load_folder"
    bl_description = "Reload deform profiles"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        z_deform['sna_deform_rofiles_var'] = []
        z_deform['sna_hide_panel_vg_interpolation'] = True
        z_deform['sna_hide_panel_new_profile'] = True
        z_deform['sna_hide_main_panel'] = False
        z_deform['sna_hide_panel_edit_profile'] = True
        bpy.context.scene.sna_selected_deform_frofile = ''
        for i_0B06F in range(len([f for f in os.listdir(bpy.context.scene.sna_folder_path) if os.path.isfile(os.path.join(bpy.context.scene.sna_folder_path, f))])):
            z_deform['sna_deform_rofiles_var'].append([f for f in os.listdir(bpy.context.scene.sna_folder_path) if os.path.isfile(os.path.join(bpy.context.scene.sna_folder_path, f))][i_0B06F])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Axis_Y_27580(bpy.types.Operator):
    bl_idname = "sna.set_axis_y_27580"
    bl_label = "set_axis_y"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_axis = 'y'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Direction__B507F(bpy.types.Operator):
    bl_idname = "sna.set_direction__b507f"
    bl_label = "set_direction_-"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_direction = '-'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Axis_X_3B425(bpy.types.Operator):
    bl_idname = "sna.set_axis_x_3b425"
    bl_label = "set_axis_x"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_axis = 'x'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Direction__8Ae93(bpy.types.Operator):
    bl_idname = "sna.set_direction__8ae93"
    bl_label = "set_direction_+"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_direction = '+'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Select_Deform_Profile_207Bd(bpy.types.Operator):
    bl_idname = "sna.select_deform_profile_207bd"
    bl_label = "select_deform_profile"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_op_select_deform_profile_string: bpy.props.StringProperty(name='OP_select_deform_profile_string', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_selected_deform_frofile = self.sna_op_select_deform_profile_string
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def load_pre_handler_3A5BF(dummy):
    bpy.context.scene.sna_folder_path = os.path.join(sna_blender_appdata_path_22557_F2E82()[2],sna_string_all_lowercase_3D9E1_65DB2('Z Deform').replace(' ', '_'),'assets')
    bpy.ops.sna.load_folder_d8907('INVOKE_DEFAULT', )


@persistent
def load_post_handler_073DC(dummy):
    bpy.context.scene.sna_folder_path = os.path.join(sna_blender_appdata_path_22557_F2E82()[2],sna_string_all_lowercase_3D9E1_65DB2('Z Deform').replace(' ', '_'),'assets')
    bpy.ops.sna.load_folder_d8907('INVOKE_DEFAULT', )


class SNA_OT_Duplicate_Object_4Ba36(bpy.types.Operator):
    bl_idname = "sna.duplicate_object_4ba36"
    bl_label = "duplicate_object"
    bl_description = "Non distructive"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_duplicate = (not bpy.context.scene.sna_duplicate)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Vertexgroup_Mode_94C56(bpy.types.Operator):
    bl_idname = "sna.vertexgroup_mode_94c56"
    bl_label = "vertexgroup_mode"
    bl_description = "Vertex Group mode"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_vertexgroup_mode = (not bpy.context.scene.sna_vertexgroup_mode)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Create_New_Profile_84C13(bpy.types.Operator):
    bl_idname = "sna.create_new_profile_84c13"
    bl_label = "Create New Profile"
    bl_description = "Create New Deform Profile"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not (not ((not (not bpy.context.view_layer.objects.selected)) and os.path.exists(bpy.context.scene.sna_folder_path) and os.path.isdir(bpy.context.scene.sna_folder_path) and (bpy.context.scene.sna_folder_path != '') and ('' != bpy.context.scene.sna_new_profile_name)))

    def execute(self, context):
        x_highest_0_829a6, x_lowest_1_829a6, y_highest_2_829a6, y_lowest_3_829a6, z_highest_4_829a6, z_lowest_5_829a6 = sna_active_object_higest_lowest_vertex_values_49975_829A6()
        for i_D4722 in range(len(bpy.context.active_object.data.vertices)):
            vertex_index_in_range_0_ef1f5 = sna_get_affected_vertex_index_list_v2_EB1A2_EF1F5(bpy.context.scene.sna_step_over, i_D4722, (y_highest_2_829a6 if (bpy.context.scene.sna_axis == 'y') else x_highest_0_829a6), (y_lowest_3_829a6 if (bpy.context.scene.sna_axis == 'y') else x_lowest_1_829a6), bpy.context.scene.sna_axis, bpy.context.scene.sna_direction, bpy.context.scene.sna_tollerance)
            for i_B3639 in range(len(vertex_index_in_range_0_ef1f5)):
                with open(bpy.context.scene.sna_folder_path + '\\' + bpy.context.scene.sna_new_profile_name.replace(' ', '_') + '.txt', mode='a') as file_8A494:
                    file_8A494.write(str(bpy.context.active_object.data.vertices[vertex_index_in_range_0_ef1f5[i_B3639]].co[2]) + '\n')
        z_deform['sna_hide_panel_new_profile'] = (not z_deform['sna_hide_panel_new_profile'])
        bpy.context.scene.sna_new_profile_name = ''
        bpy.ops.sna.load_folder_d8907('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_New_Profile_Panel_182D2(bpy.types.Operator):
    bl_idname = "sna.toggle_new_profile_panel_182d2"
    bl_label = "toggle_new_profile_panel"
    bl_description = "Toggle New profile settings menu"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if z_deform['sna_hide_panel_new_profile']:
            z_deform['sna_hide_panel_new_profile'] = False
            z_deform['sna_hide_panel_edit_profile'] = True
            z_deform['sna_hide_main_panel'] = True
            z_deform['sna_hide_panel_vg_interpolation'] = True
        else:
            z_deform['sna_hide_panel_new_profile'] = True
            z_deform['sna_hide_panel_edit_profile'] = True
            z_deform['sna_hide_main_panel'] = False
            z_deform['sna_hide_panel_vg_interpolation'] = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Delete_Profile_53Ca7(bpy.types.Operator):
    bl_idname = "sna.delete_profile_53ca7"
    bl_label = "Delete Profile"
    bl_description = "Remove"
    bl_options = {"REGISTER", "UNDO"}
    sna_file: bpy.props.StringProperty(name='file', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_delete_file_v2_AB1FA_14C79(os.path.join(bpy.context.scene.sna_folder_path,self.sna_file))
        bpy.ops.sna.load_folder_d8907('INVOKE_DEFAULT', )
        print('', os.path.join(bpy.context.scene.sna_folder_path,self.sna_file))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Edit_Profile_74De4(bpy.types.Operator):
    bl_idname = "sna.toggle_edit_profile_74de4"
    bl_label = "toggle_edit_profile"
    bl_description = "Toggle New profile settings menu"
    bl_options = {"REGISTER", "UNDO"}
    sna_profile_name: bpy.props.StringProperty(name='profile_name', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if z_deform['sna_hide_panel_edit_profile']:
            z_deform['sna_hide_main_panel'] = True
            z_deform['sna_hide_panel_new_profile'] = True
            z_deform['sna_hide_panel_edit_profile'] = True
            z_deform['sna_hide_panel_vg_interpolation'] = True
            edit_profile['sna_profile_to_edit'] = self.sna_profile_name
            bpy.ops.sna.load_profile_to_edit_3ed65('INVOKE_DEFAULT', )
        else:
            z_deform['sna_hide_main_panel'] = False
            z_deform['sna_hide_panel_new_profile'] = False
            z_deform['sna_hide_panel_edit_profile'] = True
            z_deform['sna_hide_panel_vg_interpolation'] = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_edit_profile_9DE49(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_edit_profile_9DE49'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 4
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_Z_DEFORM_D14C9'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (z_deform['sna_hide_panel_edit_profile'])

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_1CF30 = layout.box()
        box_1CF30.alert = False
        box_1CF30.enabled = True
        box_1CF30.active = True
        box_1CF30.use_property_split = False
        box_1CF30.use_property_decorate = False
        box_1CF30.alignment = 'Expand'.upper()
        box_1CF30.scale_x = 1.0
        box_1CF30.scale_y = 1.0
        if not True: box_1CF30.operator_context = "EXEC_DEFAULT"
        row_BC1E0 = box_1CF30.row(heading='', align=False)
        row_BC1E0.alert = False
        row_BC1E0.enabled = True
        row_BC1E0.active = True
        row_BC1E0.use_property_split = False
        row_BC1E0.use_property_decorate = False
        row_BC1E0.scale_x = 1.0
        row_BC1E0.scale_y = 1.0
        row_BC1E0.alignment = 'Expand'.upper()
        if not True: row_BC1E0.operator_context = "EXEC_DEFAULT"
        op = row_BC1E0.operator('sna.cancle_edit_66fb5', text='', icon_value=6, emboss=True, depress=False)
        row_BC1E0.label(text='Edit: ' + bpy.context.scene.sna_selected_deform_frofile, icon_value=0)
        op = row_BC1E0.operator('sna.save_edited_profile_e9009', text='', icon_value=36, emboss=True, depress=False)
        for i_C4CED in range(len(edit_profile['sna_value_list'])):
            row_31E4C = layout.row(heading=str(i_C4CED), align=True)
            row_31E4C.alert = False
            row_31E4C.enabled = True
            row_31E4C.active = True
            row_31E4C.use_property_split = False
            row_31E4C.use_property_decorate = False
            row_31E4C.scale_x = 1.0
            row_31E4C.scale_y = 1.0
            row_31E4C.alignment = 'Expand'.upper()
            if not True: row_31E4C.operator_context = "EXEC_DEFAULT"
            row_0A4BA = row_31E4C.row(heading='', align=False)
            row_0A4BA.alert = False
            row_0A4BA.enabled = True
            row_0A4BA.active = True
            row_0A4BA.use_property_split = False
            row_0A4BA.use_property_decorate = False
            row_0A4BA.scale_x = 1.0
            row_0A4BA.scale_y = 1.0
            row_0A4BA.alignment = 'Left'.upper()
            if not True: row_0A4BA.operator_context = "EXEC_DEFAULT"
            row_0A4BA.label(text=str(i_C4CED), icon_value=0)
            row_5B309 = row_31E4C.row(heading='', align=True)
            row_5B309.alert = False
            row_5B309.enabled = True
            row_5B309.active = True
            row_5B309.use_property_split = False
            row_5B309.use_property_decorate = False
            row_5B309.scale_x = 1.0
            row_5B309.scale_y = 1.0
            row_5B309.alignment = 'Expand'.upper()
            if not True: row_5B309.operator_context = "EXEC_DEFAULT"
            row_5B309.label(text=str(edit_profile['sna_value_list'][i_C4CED]), icon_value=0)
            op = row_5B309.operator('sna.move_up_33ba5', text='', icon_value=7, emboss=True, depress=False)
            op.sna_index = i_C4CED
            op = row_5B309.operator('sna.move_down_96399', text='', icon_value=5, emboss=True, depress=False)
            op.sna_index = i_C4CED
            op = row_5B309.operator('sna.remove_cab85', text='', icon_value=19, emboss=True, depress=False)
            op.sna_index = i_C4CED


class SNA_PT_interpolated_deform_5FA5C(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_interpolated_deform_5FA5C'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_Z_DEFORM_D14C9'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (z_deform['sna_hide_panel_vg_interpolation'])

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_AB617 = layout.box()
        box_AB617.alert = False
        box_AB617.enabled = True
        box_AB617.active = True
        box_AB617.use_property_split = False
        box_AB617.use_property_decorate = False
        box_AB617.alignment = 'Expand'.upper()
        box_AB617.scale_x = 1.0
        box_AB617.scale_y = 1.0
        if not True: box_AB617.operator_context = "EXEC_DEFAULT"
        row_152C0 = box_AB617.row(heading='', align=False)
        row_152C0.alert = False
        row_152C0.enabled = True
        row_152C0.active = True
        row_152C0.use_property_split = False
        row_152C0.use_property_decorate = False
        row_152C0.scale_x = 1.0
        row_152C0.scale_y = 1.0
        row_152C0.alignment = 'Expand'.upper()
        if not True: row_152C0.operator_context = "EXEC_DEFAULT"
        row_152C0.label(text='Vertexgroup mode settings:', icon_value=0)
        row_20360 = box_AB617.row(heading='', align=False)
        row_20360.alert = False
        row_20360.enabled = True
        row_20360.active = True
        row_20360.use_property_split = False
        row_20360.use_property_decorate = False
        row_20360.scale_x = 1.0
        row_20360.scale_y = 1.0
        row_20360.alignment = 'Expand'.upper()
        if not True: row_20360.operator_context = "EXEC_DEFAULT"
        op = row_20360.operator('sna.set_mode_4e10a', text='interpolated profile', icon_value=722, emboss=True, depress=(0 == interpolated_deform['sna_mode']))
        op.sna_mode = 0
        op = row_20360.operator('sna.set_mode_4e10a', text='Custom curve', icon_value=323, emboss=True, depress=(1 == interpolated_deform['sna_mode']))
        op.sna_mode = 1
        if ('circle' == interpolated_deform['sna_mode']):
            row_739EF = box_AB617.row(heading='', align=True)
            row_739EF.alert = False
            row_739EF.enabled = True
            row_739EF.active = True
            row_739EF.use_property_split = False
            row_739EF.use_property_decorate = False
            row_739EF.scale_x = 1.0
            row_739EF.scale_y = 1.0
            row_739EF.alignment = 'Expand'.upper()
            if not True: row_739EF.operator_context = "EXEC_DEFAULT"
            row_739EF.prop(bpy.context.scene, 'sna_id_start_angle', text='Start Angle', icon_value=0, emboss=True)
            row_739EF.prop(bpy.context.scene, 'sna_id_end_angle', text='End Angle', icon_value=0, emboss=True)
        row_17211 = box_AB617.row(heading='', align=True)
        row_17211.alert = False
        row_17211.enabled = True
        row_17211.active = True
        row_17211.use_property_split = False
        row_17211.use_property_decorate = False
        row_17211.scale_x = 1.0
        row_17211.scale_y = 1.0
        row_17211.alignment = 'Expand'.upper()
        if not True: row_17211.operator_context = "EXEC_DEFAULT"
        op = row_17211.operator('sna.set_quallity_3d1c4', text='1', icon_value=0, emboss=True, depress=(interpolated_deform['sna_quality'] == 1))
        op.sna_quallity = 1
        op = row_17211.operator('sna.set_quallity_3d1c4', text='2', icon_value=0, emboss=True, depress=(interpolated_deform['sna_quality'] == 2))
        op.sna_quallity = 2
        op = row_17211.operator('sna.set_quallity_3d1c4', text='3', icon_value=0, emboss=True, depress=(interpolated_deform['sna_quality'] == 3))
        op.sna_quallity = 3
        op = row_17211.operator('sna.set_quallity_3d1c4', text='4', icon_value=0, emboss=True, depress=(interpolated_deform['sna_quality'] == 4))
        op.sna_quallity = 4
        row_6DEA3 = box_AB617.row(heading='', align=True)
        row_6DEA3.alert = False
        row_6DEA3.enabled = ((interpolated_deform['sna_quality'] != 0) and ('' != interpolated_deform['sna_mode']))
        row_6DEA3.active = True
        row_6DEA3.use_property_split = False
        row_6DEA3.use_property_decorate = False
        row_6DEA3.scale_x = 1.0
        row_6DEA3.scale_y = 1.0
        row_6DEA3.alignment = 'Expand'.upper()
        if not True: row_6DEA3.operator_context = "EXEC_DEFAULT"
        op = row_6DEA3.operator('sna.interpolated_deform_run_049ba', text='Run', icon_value=495, emboss=True, depress=False)


class SNA_PT_DEFORM_SETTINGS_A84E1(bpy.types.Panel):
    bl_label = 'deform settings'
    bl_idname = 'SNA_PT_DEFORM_SETTINGS_A84E1'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_Z_DEFORM_D14C9'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (z_deform['sna_hide_main_panel'])

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_80C08 = layout.box()
        box_80C08.alert = False
        box_80C08.enabled = True
        box_80C08.active = True
        box_80C08.use_property_split = False
        box_80C08.use_property_decorate = False
        box_80C08.alignment = 'Expand'.upper()
        box_80C08.scale_x = 1.0
        box_80C08.scale_y = 1.0
        if not True: box_80C08.operator_context = "EXEC_DEFAULT"
        row_DB79E = box_80C08.row(heading='', align=True)
        row_DB79E.alert = False
        row_DB79E.enabled = (((not (z_deform['sna_deform_rofiles_var'] == [])) and False and (not bpy.context.scene.sna_vertexgroup_mode)) or (not bpy.context.scene.sna_vertexgroup_mode))
        row_DB79E.active = True
        row_DB79E.use_property_split = False
        row_DB79E.use_property_decorate = False
        row_DB79E.scale_x = 1.0
        row_DB79E.scale_y = 1.0
        row_DB79E.alignment = 'Expand'.upper()
        if not True: row_DB79E.operator_context = "EXEC_DEFAULT"
        row_DB79E.prop(bpy.context.scene, 'sna_tollerance', text='Tollerance', icon_value=0, emboss=True)
        row_DB79E.prop(bpy.context.scene, 'sna_step_over', text='Step size', icon_value=0, emboss=True)
        row_14A29 = box_80C08.row(heading='', align=False)
        row_14A29.alert = False
        row_14A29.enabled = (not (z_deform['sna_deform_rofiles_var'] == []))
        row_14A29.active = True
        row_14A29.use_property_split = False
        row_14A29.use_property_decorate = False
        row_14A29.scale_x = 1.0
        row_14A29.scale_y = 1.0
        row_14A29.alignment = 'Expand'.upper()
        if not True: row_14A29.operator_context = "EXEC_DEFAULT"
        row_0223C = row_14A29.row(heading='', align=True)
        row_0223C.alert = False
        row_0223C.enabled = (not bpy.context.scene.sna_vertexgroup_mode)
        row_0223C.active = True
        row_0223C.use_property_split = False
        row_0223C.use_property_decorate = False
        row_0223C.scale_x = 1.0
        row_0223C.scale_y = 1.0
        row_0223C.alignment = 'Expand'.upper()
        if not True: row_0223C.operator_context = "EXEC_DEFAULT"
        op = row_0223C.operator('sna.set_axis_x_3b425', text='', icon_value=load_preview_icon(r'C:\Users\admin\AppData\Roaming\Blender Foundation\Blender\3.3\scripts\addons\serpens_custom_icons_for_icon_node\assets\icon packs\abc_white\x.png'), emboss=True, depress=(not (bpy.context.scene.sna_axis == 'y')))
        op = row_0223C.operator('sna.set_axis_y_27580', text='', icon_value=load_preview_icon(r'C:\Users\admin\AppData\Roaming\Blender Foundation\Blender\3.3\scripts\addons\serpens_custom_icons_for_icon_node\assets\icon packs\abc_white\y.png'), emboss=True, depress=(bpy.context.scene.sna_axis == 'y'))
        row_8F1F9 = row_14A29.row(heading='', align=True)
        row_8F1F9.alert = False
        row_8F1F9.enabled = (not bpy.context.scene.sna_vertexgroup_mode)
        row_8F1F9.active = True
        row_8F1F9.use_property_split = False
        row_8F1F9.use_property_decorate = False
        row_8F1F9.scale_x = 1.0
        row_8F1F9.scale_y = 1.0
        row_8F1F9.alignment = 'Expand'.upper()
        if not True: row_8F1F9.operator_context = "EXEC_DEFAULT"
        op = row_8F1F9.operator('sna.set_direction__8ae93', text='', icon_value=31, emboss=True, depress=(bpy.context.scene.sna_direction == '+'))
        op = row_8F1F9.operator('sna.set_direction__b507f', text='', icon_value=32, emboss=True, depress=(not (bpy.context.scene.sna_direction == '+')))
        row_7C466 = row_14A29.row(heading='', align=True)
        row_7C466.alert = False
        row_7C466.enabled = True
        row_7C466.active = True
        row_7C466.use_property_split = False
        row_7C466.use_property_decorate = False
        row_7C466.scale_x = 1.2000000476837158
        row_7C466.scale_y = 1.0
        row_7C466.alignment = 'Expand'.upper()
        if not True: row_7C466.operator_context = "EXEC_DEFAULT"
        row_DC77B = row_7C466.row(heading='', align=True)
        row_DC77B.alert = False
        row_DC77B.enabled = True
        row_DC77B.active = True
        row_DC77B.use_property_split = False
        row_DC77B.use_property_decorate = False
        row_DC77B.scale_x = 1.2000000476837158
        row_DC77B.scale_y = 1.0
        row_DC77B.alignment = 'Expand'.upper()
        if not True: row_DC77B.operator_context = "EXEC_DEFAULT"
        op = row_DC77B.operator('sna.vertexgroup_mode_94c56', text='', icon_value=201, emboss=True, depress=bpy.context.scene.sna_vertexgroup_mode)
        op = row_7C466.operator('sna.duplicate_object_4ba36', text='', icon_value=761, emboss=True, depress=bpy.context.scene.sna_duplicate)
        op = row_7C466.operator('sna.run_hight_deform_53233', text='Run', icon_value=495, emboss=True, depress=False)
        op.sna_axis = bpy.context.scene.sna_axis
        op.sna_direction = bpy.context.scene.sna_direction
        op.sna_duplicate = bpy.context.scene.sna_duplicate
        op.sna_step_over = bpy.context.scene.sna_step_over
        op.sna_tollerance = bpy.context.scene.sna_tollerance
        op.sna_deform_profile = bpy.context.scene.sna_selected_deform_frofile


class SNA_PT_NEW_PROFILE_SETTINGS_DFB47(bpy.types.Panel):
    bl_label = 'New Profile Settings'
    bl_idname = 'SNA_PT_NEW_PROFILE_SETTINGS_DFB47'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_Z_DEFORM_D14C9'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (z_deform['sna_hide_panel_new_profile'])

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_CFC5E = layout.box()
        box_CFC5E.alert = False
        box_CFC5E.enabled = True
        box_CFC5E.active = True
        box_CFC5E.use_property_split = False
        box_CFC5E.use_property_decorate = False
        box_CFC5E.alignment = 'Expand'.upper()
        box_CFC5E.scale_x = 1.0
        box_CFC5E.scale_y = 1.0
        if not True: box_CFC5E.operator_context = "EXEC_DEFAULT"
        row_21455 = box_CFC5E.row(heading='', align=True)
        row_21455.alert = False
        row_21455.enabled = True
        row_21455.active = True
        row_21455.use_property_split = False
        row_21455.use_property_decorate = False
        row_21455.scale_x = 1.0
        row_21455.scale_y = 1.0
        row_21455.alignment = 'Expand'.upper()
        if not True: row_21455.operator_context = "EXEC_DEFAULT"
        row_21455.label(text='New Profile Name:', icon_value=0)
        row_21455.prop(bpy.context.scene, 'sna_new_profile_name', text='', icon_value=0, emboss=True)
        row_D7DFA = box_CFC5E.row(heading='', align=True)
        row_D7DFA.alert = False
        row_D7DFA.enabled = True
        row_D7DFA.active = True
        row_D7DFA.use_property_split = False
        row_D7DFA.use_property_decorate = False
        row_D7DFA.scale_x = 1.0
        row_D7DFA.scale_y = 1.0
        row_D7DFA.alignment = 'Expand'.upper()
        if not True: row_D7DFA.operator_context = "EXEC_DEFAULT"
        row_D7DFA.prop(bpy.context.scene, 'sna_tollerance', text='Tollerance', icon_value=0, emboss=True)
        row_D7DFA.prop(bpy.context.scene, 'sna_step_over', text='Step size', icon_value=0, emboss=True)
        row_0A238 = box_CFC5E.row(heading='', align=False)
        row_0A238.alert = False
        row_0A238.enabled = True
        row_0A238.active = True
        row_0A238.use_property_split = False
        row_0A238.use_property_decorate = False
        row_0A238.scale_x = 1.0
        row_0A238.scale_y = 1.0
        row_0A238.alignment = 'Expand'.upper()
        if not True: row_0A238.operator_context = "EXEC_DEFAULT"
        row_5BAE4 = row_0A238.row(heading='', align=True)
        row_5BAE4.alert = False
        row_5BAE4.enabled = True
        row_5BAE4.active = True
        row_5BAE4.use_property_split = False
        row_5BAE4.use_property_decorate = False
        row_5BAE4.scale_x = 1.0
        row_5BAE4.scale_y = 1.0
        row_5BAE4.alignment = 'Expand'.upper()
        if not True: row_5BAE4.operator_context = "EXEC_DEFAULT"
        op = row_5BAE4.operator('sna.set_axis_x_3b425', text='', icon_value=load_preview_icon(r'C:\Users\admin\AppData\Roaming\Blender Foundation\Blender\3.3\scripts\addons\serpens_custom_icons_for_icon_node\assets\icon packs\abc_white\x.png'), emboss=True, depress=(not (bpy.context.scene.sna_axis == 'y')))
        op = row_5BAE4.operator('sna.set_axis_y_27580', text='', icon_value=load_preview_icon(r'C:\Users\admin\AppData\Roaming\Blender Foundation\Blender\3.3\scripts\addons\serpens_custom_icons_for_icon_node\assets\icon packs\abc_white\y.png'), emboss=True, depress=(bpy.context.scene.sna_axis == 'y'))
        row_739CD = row_0A238.row(heading='', align=True)
        row_739CD.alert = False
        row_739CD.enabled = True
        row_739CD.active = True
        row_739CD.use_property_split = False
        row_739CD.use_property_decorate = False
        row_739CD.scale_x = 1.0
        row_739CD.scale_y = 1.0
        row_739CD.alignment = 'Expand'.upper()
        if not True: row_739CD.operator_context = "EXEC_DEFAULT"
        op = row_739CD.operator('sna.set_direction__8ae93', text='', icon_value=31, emboss=True, depress=(bpy.context.scene.sna_direction == '+'))
        op = row_739CD.operator('sna.set_direction__b507f', text='', icon_value=32, emboss=True, depress=(not (bpy.context.scene.sna_direction == '+')))
        row_09E91 = row_0A238.row(heading='', align=False)
        row_09E91.alert = False
        row_09E91.enabled = ((not (not bpy.context.view_layer.objects.selected)) and os.path.exists(bpy.context.scene.sna_folder_path) and os.path.isdir(bpy.context.scene.sna_folder_path) and (bpy.context.scene.sna_folder_path != '') and ('' != bpy.context.scene.sna_new_profile_name))
        row_09E91.active = True
        row_09E91.use_property_split = False
        row_09E91.use_property_decorate = False
        row_09E91.scale_x = 1.0
        row_09E91.scale_y = 1.0
        row_09E91.alignment = 'Expand'.upper()
        if not True: row_09E91.operator_context = "EXEC_DEFAULT"
        op = row_09E91.operator('sna.create_new_profile_84c13', text='Create', icon_value=69, emboss=True, depress=False)


class SNA_PT_DEFORM_PROFILES_LIST_A35E9(bpy.types.Panel):
    bl_label = 'Deform Profiles List'
    bl_idname = 'SNA_PT_DEFORM_PROFILES_LIST_A35E9'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_Z_DEFORM_D14C9'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (z_deform['sna_hide_main_panel'])

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        for i_BBF5B in range(len(z_deform['sna_deform_rofiles_var'])):
            row_E46BF = layout.row(heading='', align=True)
            row_E46BF.alert = False
            row_E46BF.enabled = True
            row_E46BF.active = True
            row_E46BF.use_property_split = False
            row_E46BF.use_property_decorate = False
            row_E46BF.scale_x = 1.0
            row_E46BF.scale_y = 1.0
            row_E46BF.alignment = 'Expand'.upper()
            if not True: row_E46BF.operator_context = "EXEC_DEFAULT"
            op = row_E46BF.operator('sna.select_deform_profile_207bd', text=z_deform['sna_deform_rofiles_var'][i_BBF5B].replace('.txt', ''), icon_value=0, emboss=True, depress=(bpy.context.scene.sna_selected_deform_frofile == z_deform['sna_deform_rofiles_var'][i_BBF5B].replace('.txt', '')))
            op.sna_op_select_deform_profile_string = z_deform['sna_deform_rofiles_var'][i_BBF5B].replace('.txt', '')
            if (z_deform['sna_deform_rofiles_var'][i_BBF5B].replace('.txt', '') == bpy.context.scene.sna_selected_deform_frofile):
                op = row_E46BF.operator('sna.toggle_edit_profile_74de4', text='', icon_value=94, emboss=True, depress=False)
                op.sna_profile_name = z_deform['sna_deform_rofiles_var'][i_BBF5B].replace('.txt', '')
                op = row_E46BF.operator('sna.delete_profile_53ca7', text='', icon_value=21, emboss=True, depress=False)
                op.sna_file = z_deform['sna_deform_rofiles_var'][i_BBF5B]


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_folder_path = bpy.props.StringProperty(name='folder_path', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_selected_deform_frofile = bpy.props.StringProperty(name='Selected_deform_frofile', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_tollerance = bpy.props.FloatProperty(name='tollerance', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=3)
    bpy.types.Scene.sna_axis = bpy.props.StringProperty(name='axis', description='', default='y', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_step_over = bpy.props.FloatProperty(name='step_over', description='', default=1.0, subtype='NONE', unit='NONE', step=3, precision=3)
    bpy.types.Scene.sna_direction = bpy.props.StringProperty(name='direction', description='', default='-', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_duplicate = bpy.props.BoolProperty(name='duplicate', description='', default=True)
    bpy.types.Scene.sna_vertexgroup_mode = bpy.props.BoolProperty(name='vertexgroup_mode', description='', default=False)
    bpy.types.Scene.sna_new_profile_name = bpy.props.StringProperty(name='New Profile Name', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_edit_line = bpy.props.FloatProperty(name='edit_line', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Scene.sna_id_start_angle = bpy.props.FloatProperty(name='ID_start_angle', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Scene.sna_id_end_angle = bpy.props.FloatProperty(name='ID_end_angle', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Scene.sna_edit_index = bpy.props.IntProperty(name='edit_index', description='', default=-1, subtype='NONE', update=sna_update_sna_edit_index_AFEA5)
    bpy.utils.register_class(SNA_OT_Cancle_Edit_66Fb5)
    bpy.utils.register_class(SNA_OT_Load_Profile_To_Edit_3Ed65)
    bpy.utils.register_class(SNA_OT_Save_Edited_Profile_E9009)
    bpy.utils.register_class(SNA_OT_Remove_Cab85)
    bpy.utils.register_class(SNA_OT_Move_Down_96399)
    bpy.utils.register_class(SNA_OT_Move_Up_33Ba5)
    bpy.utils.register_class(SNA_OT_Edit_Index_Dfdda)
    bpy.utils.register_class(SNA_OT_Save_Edit_Line_8A2D7)
    bpy.utils.register_class(SNA_OT_Set_Mode_4E10A)
    bpy.utils.register_class(SNA_OT_Set_Quallity_3D1C4)
    bpy.utils.register_class(SNA_OT_Interpolated_Deform_Run_049Ba)
    bpy.utils.register_class(SNA_OT_Make_Random_Int_Ac6Ca)
    bpy.utils.register_class(SNA_PT_Z_DEFORM_D14C9)
    bpy.utils.register_class(SNA_OT_Run_Hight_Deform_53233)
    bpy.utils.register_class(SNA_OT_Load_Folder_D8907)
    bpy.utils.register_class(SNA_OT_Set_Axis_Y_27580)
    bpy.utils.register_class(SNA_OT_Set_Direction__B507F)
    bpy.utils.register_class(SNA_OT_Set_Axis_X_3B425)
    bpy.utils.register_class(SNA_OT_Set_Direction__8Ae93)
    bpy.utils.register_class(SNA_OT_Select_Deform_Profile_207Bd)
    bpy.app.handlers.load_pre.append(load_pre_handler_3A5BF)
    bpy.app.handlers.load_post.append(load_post_handler_073DC)
    bpy.utils.register_class(SNA_OT_Duplicate_Object_4Ba36)
    bpy.utils.register_class(SNA_OT_Vertexgroup_Mode_94C56)
    bpy.utils.register_class(SNA_OT_Create_New_Profile_84C13)
    bpy.utils.register_class(SNA_OT_Toggle_New_Profile_Panel_182D2)
    bpy.utils.register_class(SNA_OT_Delete_Profile_53Ca7)
    bpy.utils.register_class(SNA_OT_Toggle_Edit_Profile_74De4)
    bpy.utils.register_class(SNA_PT_edit_profile_9DE49)
    bpy.utils.register_class(SNA_PT_interpolated_deform_5FA5C)
    bpy.utils.register_class(SNA_PT_DEFORM_SETTINGS_A84E1)
    bpy.utils.register_class(SNA_PT_NEW_PROFILE_SETTINGS_DFB47)
    bpy.utils.register_class(SNA_PT_DEFORM_PROFILES_LIST_A35E9)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_edit_index
    del bpy.types.Scene.sna_id_end_angle
    del bpy.types.Scene.sna_id_start_angle
    del bpy.types.Scene.sna_edit_line
    del bpy.types.Scene.sna_new_profile_name
    del bpy.types.Scene.sna_vertexgroup_mode
    del bpy.types.Scene.sna_duplicate
    del bpy.types.Scene.sna_direction
    del bpy.types.Scene.sna_step_over
    del bpy.types.Scene.sna_axis
    del bpy.types.Scene.sna_tollerance
    del bpy.types.Scene.sna_selected_deform_frofile
    del bpy.types.Scene.sna_folder_path
    bpy.utils.unregister_class(SNA_OT_Cancle_Edit_66Fb5)
    bpy.utils.unregister_class(SNA_OT_Load_Profile_To_Edit_3Ed65)
    bpy.utils.unregister_class(SNA_OT_Save_Edited_Profile_E9009)
    bpy.utils.unregister_class(SNA_OT_Remove_Cab85)
    bpy.utils.unregister_class(SNA_OT_Move_Down_96399)
    bpy.utils.unregister_class(SNA_OT_Move_Up_33Ba5)
    bpy.utils.unregister_class(SNA_OT_Edit_Index_Dfdda)
    bpy.utils.unregister_class(SNA_OT_Save_Edit_Line_8A2D7)
    bpy.utils.unregister_class(SNA_OT_Set_Mode_4E10A)
    bpy.utils.unregister_class(SNA_OT_Set_Quallity_3D1C4)
    bpy.utils.unregister_class(SNA_OT_Interpolated_Deform_Run_049Ba)
    bpy.utils.unregister_class(SNA_OT_Make_Random_Int_Ac6Ca)
    bpy.utils.unregister_class(SNA_PT_Z_DEFORM_D14C9)
    bpy.utils.unregister_class(SNA_OT_Run_Hight_Deform_53233)
    bpy.utils.unregister_class(SNA_OT_Load_Folder_D8907)
    bpy.utils.unregister_class(SNA_OT_Set_Axis_Y_27580)
    bpy.utils.unregister_class(SNA_OT_Set_Direction__B507F)
    bpy.utils.unregister_class(SNA_OT_Set_Axis_X_3B425)
    bpy.utils.unregister_class(SNA_OT_Set_Direction__8Ae93)
    bpy.utils.unregister_class(SNA_OT_Select_Deform_Profile_207Bd)
    bpy.app.handlers.load_pre.remove(load_pre_handler_3A5BF)
    bpy.app.handlers.load_post.remove(load_post_handler_073DC)
    bpy.utils.unregister_class(SNA_OT_Duplicate_Object_4Ba36)
    bpy.utils.unregister_class(SNA_OT_Vertexgroup_Mode_94C56)
    bpy.utils.unregister_class(SNA_OT_Create_New_Profile_84C13)
    bpy.utils.unregister_class(SNA_OT_Toggle_New_Profile_Panel_182D2)
    bpy.utils.unregister_class(SNA_OT_Delete_Profile_53Ca7)
    bpy.utils.unregister_class(SNA_OT_Toggle_Edit_Profile_74De4)
    bpy.utils.unregister_class(SNA_PT_edit_profile_9DE49)
    bpy.utils.unregister_class(SNA_PT_interpolated_deform_5FA5C)
    bpy.utils.unregister_class(SNA_PT_DEFORM_SETTINGS_A84E1)
    bpy.utils.unregister_class(SNA_PT_NEW_PROFILE_SETTINGS_DFB47)
    bpy.utils.unregister_class(SNA_PT_DEFORM_PROFILES_LIST_A35E9)
