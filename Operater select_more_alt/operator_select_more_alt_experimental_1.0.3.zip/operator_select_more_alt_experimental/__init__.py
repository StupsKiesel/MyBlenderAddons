# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Operator: Select_more_alt (experimental)",
    "author" : "Stups_Kiesel", 
    "description" : "STRG + ALT + NUMPAD_+",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 3),
    "location" : "Edit Mesh",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import bmesh




def string_to_type(value, to_type, default):
    try:
        value = to_type(value)
    except:
        value = default
    return value


addon_keymaps = {}
_icons = None
nodetree = {'sna_threshold': 0.75, }


def sna_toggle_edit_mode_2EA60_2F06A():
    bpy.ops.object.editmode_toggle()
    return


def sna_toggle_edit_mode_2EA60_8E04A():
    bpy.ops.object.editmode_toggle()
    return


class SNA_OT_Select_More_Alt_8850E(bpy.types.Operator):
    bl_idname = "sna.select_more_alt_8850e"
    bl_label = "select_more_alt"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_threshold: bpy.props.FloatProperty(name='Threshold', description='', default=0.75, subtype='NONE', unit='NONE', min=0.0, max=1.0, step=1, precision=2)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not (not 'EDIT_MESH'==bpy.context.mode)

    def execute(self, context):
        bm_1B195 = bmesh.new()
        if bpy.context.view_layer.objects.active:
            if bpy.context.view_layer.objects.active.mode == 'EDIT' and True:
                bm_1B195 = bmesh.from_edit_mesh(bpy.context.view_layer.objects.active.data)
            else:
                if False:
                    dg = bpy.context.evaluated_depsgraph_get()
                    bm_1B195.from_mesh(bpy.context.view_layer.objects.active.evaluated_get(dg).to_mesh())
                else:
                    bm_1B195.from_mesh(bpy.context.view_layer.objects.active.data)
        if False:
            bm_1B195.transform(bpy.context.view_layer.objects.active.matrix_world)
        bm_1B195.verts.ensure_lookup_table()
        bm_1B195.faces.ensure_lookup_table()
        bm_1B195.edges.ensure_lookup_table()
        for i_84EA5 in range(len(bm_1B195.faces)):
            if bm_1B195.faces[i_84EA5].select:
                for i_AF890 in range(len(bm_1B195.faces[i_84EA5].edges)):
                    if (bm_1B195.faces[i_84EA5].edges[i_AF890].link_faces[0].select != bm_1B195.faces[i_84EA5].edges[i_AF890].link_faces[1].select):
                        if sna_vector_whithin_threshold_03766((bm_1B195.faces[i_84EA5].edges[i_AF890].link_faces[0] if bm_1B195.faces[i_84EA5].edges[i_AF890].link_faces[0].select else bm_1B195.faces[i_84EA5].edges[i_AF890].link_faces[1]).normal, self.sna_threshold, (bm_1B195.faces[i_84EA5].edges[i_AF890].link_faces[1] if bm_1B195.faces[i_84EA5].edges[i_AF890].link_faces[0].select else bm_1B195.faces[i_84EA5].edges[i_AF890].link_faces[0]).normal):
                            setattr((bm_1B195.faces[i_84EA5].edges[i_AF890].link_faces[1] if bm_1B195.faces[i_84EA5].edges[i_AF890].link_faces[0].select else bm_1B195.faces[i_84EA5].edges[i_AF890].link_faces[0]), 'select', True)
        sna_toggle_edit_mode_2EA60_2F06A()
        sna_toggle_edit_mode_2EA60_8E04A()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_vector_whithin_threshold_03766(Master_Float_Vector3, threshold, Slave_Float_Vector3):
    return ((Slave_Float_Vector3[0] > float(Master_Float_Vector3[0] + string_to_type('-' + str(threshold), float, 0))) and (Slave_Float_Vector3[0] < float(Master_Float_Vector3[0] + threshold)) and (Slave_Float_Vector3[1] > float(Master_Float_Vector3[1] + string_to_type('-' + str(threshold), float, 0))) and (Slave_Float_Vector3[1] < float(Master_Float_Vector3[1] + threshold)) and (Slave_Float_Vector3[2] > float(Master_Float_Vector3[2] + string_to_type('-' + str(threshold), float, 0))) and (Slave_Float_Vector3[2] < float(Master_Float_Vector3[2] + threshold)))


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Select_More_Alt_8850E)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.select_more_alt_8850e', 'NUMPAD_PLUS', 'PRESS',
        ctrl=True, alt=True, shift=False, repeat=True)
    kmi.properties.sna_threshold = self.sna_threshold
    addon_keymaps['31DBF'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Select_More_Alt_8850E)
