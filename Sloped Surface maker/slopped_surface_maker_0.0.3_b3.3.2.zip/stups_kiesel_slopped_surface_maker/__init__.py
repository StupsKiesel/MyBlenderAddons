# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Stups_Kiesel Slopped Surface Maker",
    "author" : "Stups_Kiesel", 
    "description" : "used to create the sloped loops item set",
    "blender" : (3, 3, 2),
    "version" : (0, 0, 3),
    "location" : "",
    "warning" : "not bug free !",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import blf


addon_keymaps = {}
_icons = None
surface_maker = {'sna_v_obj_path': 'NONE', 'sna_v_obj_profile': 'NONE', 'sna_eyedropper_enable': False, }
class SNA_PT_SLOPED_SURFACE_MAKER_04E19(bpy.types.Panel):
    bl_label = 'Sloped Surface Maker'
    bl_idname = 'SNA_PT_SLOPED_SURFACE_MAKER_04E19'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Stups_Kiesel'
    bl_order = 2
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not 'OBJECT'==bpy.context.mode))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_792E1 = layout.row(heading='', align=True)
        row_792E1.alert = False
        row_792E1.enabled = True
        row_792E1.active = True
        row_792E1.use_property_split = False
        row_792E1.use_property_decorate = False
        row_792E1.scale_x = 1.2699999809265137
        row_792E1.scale_y = 1.0
        row_792E1.alignment = 'Expand'.upper()
        row_792E1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_792E1.label(text='[X] Path:', icon_value=0)
        row_792E1.label(text=str(surface_maker['sna_v_obj_path']), icon_value=0)
        row_E04E5 = row_792E1.row(heading='', align=True)
        row_E04E5.alert = False
        row_E04E5.enabled = True
        row_E04E5.active = True
        row_E04E5.use_property_split = False
        row_E04E5.use_property_decorate = False
        row_E04E5.scale_x = 1.2699999809265137
        row_E04E5.scale_y = 1.0
        row_E04E5.alignment = 'Expand'.upper()
        row_E04E5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_E04E5.operator('sna.set_obj_path_33144', text='', icon_value=35, emboss=True, depress=False)
        row_224A1 = layout.row(heading='', align=True)
        row_224A1.alert = False
        row_224A1.enabled = True
        row_224A1.active = True
        row_224A1.use_property_split = False
        row_224A1.use_property_decorate = False
        row_224A1.scale_x = 1.2699999809265137
        row_224A1.scale_y = 1.0
        row_224A1.alignment = 'Expand'.upper()
        row_224A1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_224A1.label(text='[Y] Profile:', icon_value=0)
        row_224A1.label(text=str(surface_maker['sna_v_obj_profile']), icon_value=0)
        row_FEC37 = row_224A1.row(heading='', align=True)
        row_FEC37.alert = False
        row_FEC37.enabled = True
        row_FEC37.active = True
        row_FEC37.use_property_split = False
        row_FEC37.use_property_decorate = False
        row_FEC37.scale_x = 1.2699999809265137
        row_FEC37.scale_y = 1.0
        row_FEC37.alignment = 'Expand'.upper()
        row_FEC37.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_FEC37.operator('sna.set_obj_profile_3d79e', text='', icon_value=35, emboss=True, depress=False)
        op = layout.operator('sna.create_sloped_surface_mesh_59f25', text='Create', icon_value=775, emboss=True, depress=False)


class SNA_OT_Set_Obj_Profile_3D79E(bpy.types.Operator):
    bl_idname = "sna.set_obj_profile_3d79e"
    bl_label = "set_obj_profile"
    bl_description = "Sets Object from current aktive selected object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        surface_maker['sna_v_obj_profile'] = str(bpy.context.active_object.name)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Obj_Path_33144(bpy.types.Operator):
    bl_idname = "sna.set_obj_path_33144"
    bl_label = "set_obj_path"
    bl_description = "Sets Object from current aktive selected object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        surface_maker['sna_v_obj_path'] = str(bpy.context.active_object.name)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Create_Sloped_Surface_Mesh_59F25(bpy.types.Operator):
    bl_idname = "sna.create_sloped_surface_mesh_59f25"
    bl_label = "Create_sloped_surface_mesh"
    bl_description = "Attempt to create A Mesh"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        import bgl
        import numpy as np
        obj_path = surface_maker['sna_v_obj_path']
        obj_profile = surface_maker['sna_v_obj_profile']
        obj_path_copy = surface_maker['sna_v_obj_path'] + "_copy"
        obj_profile_copy = surface_maker['sna_v_obj_profile'] + "_copy"
        # Duplicate objects and rename
        bpy.ops.object.select_all(action='DESELECT')
        bpy.data.objects[obj_profile].select_set(True)
        bpy.data.objects[obj_path].select_set(True)
        context = bpy.context
        for obj in context.selected_objects:
            name = obj.name
            copy = obj.copy()
            copy.data = copy.data.copy() # linked = False
            obj.name = f"{name}"
            copy.name = f"{name}_copy"
            obj.location.x += 0
            context.collection.objects.link(copy)
        # savety deselect
        bpy.ops.object.select_all(action='DESELECT')
        bpy.data.objects[obj_path].select_set(True)
        bpy.data.objects[obj_profile].select_set(True)
        bpy.data.objects[obj_path_copy].select_set(True)
        bpy.data.objects[obj_profile_copy].select_set(True)
        # object propertys -> instancing: for all original "path" meshes: set to vertices
        object = bpy.data.objects[obj_path]
        bpy.context.view_layer.objects.active = object
        bpy.context.object.instance_type = 'VERTS'
        bpy.ops.object.select_all(action='DESELECT')
        # object propertys -> instancing: for all copyed "loop" meshes: set to vertices
        object = bpy.data.objects[obj_profile_copy]
        bpy.context.view_layer.objects.active = object
        bpy.context.object.instance_type = 'VERTS'
        bpy.ops.object.select_all(action='DESELECT')
        # PARENTING:
        object = bpy.data.objects[obj_path]
        bpy.context.view_layer.objects.active = object
        bpy.data.objects[obj_profile].select_set(True)
        bpy.ops.object.parent_set(type='VERTEX', keep_transform=False)
        bpy.ops.object.select_all(action='DESELECT')
        object = bpy.data.objects[obj_profile_copy]
        bpy.context.view_layer.objects.active = object
        bpy.data.objects[obj_path_copy].select_set(True)
        bpy.ops.object.parent_set(type='VERTEX', keep_transform=False)
        #bpy.ops.object.select_all(action='DESELECT')
        # sellect all objects from aktive collection v1
        bpy.context.collection.objects[:]
        for obj in bpy.context.collection.all_objects:
            obj.select_set(True)
        #convert instances to mesh
        bpy.ops.object.duplicates_make_real()
        # select name pattern pattern "top" then join and make solide mesh
        object = bpy.data.objects[obj_profile]
        bpy.context.view_layer.objects.active = object
        bpy.ops.object.select_pattern(pattern=obj_profile + ".*")
        bpy.ops.object.select_pattern(pattern=obj_path)
        bpy.ops.object.select_pattern(pattern=obj_profile + ".*")
        bpy.ops.object.select_pattern(pattern=obj_profile)
        bpy.ops.object.select_pattern(pattern=obj_profile_copy)
        bpy.ops.object.join()
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.remove_doubles(threshold=0.04)
        bpy.ops.mesh.edge_face_add()
        bpy.ops.mesh.flip_normals()
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.select_all(action='DESELECT')
        surface_maker['sna_v_obj_path'] = 'NONE'
        surface_maker['sna_v_obj_profile'] = 'NONE'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_obj_path = bpy.props.PointerProperty(name='obj_path', description='', type=bpy.types.Scene)
    bpy.types.Scene.sna_obj_profile = bpy.props.PointerProperty(name='obj_profile', description='', type=bpy.types.Scene)
    bpy.utils.register_class(SNA_PT_SLOPED_SURFACE_MAKER_04E19)
    bpy.utils.register_class(SNA_OT_Set_Obj_Profile_3D79E)
    bpy.utils.register_class(SNA_OT_Set_Obj_Path_33144)
    bpy.utils.register_class(SNA_OT_Create_Sloped_Surface_Mesh_59F25)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_obj_profile
    del bpy.types.Scene.sna_obj_path
    bpy.utils.unregister_class(SNA_PT_SLOPED_SURFACE_MAKER_04E19)
    bpy.utils.unregister_class(SNA_OT_Set_Obj_Profile_3D79E)
    bpy.utils.unregister_class(SNA_OT_Set_Obj_Path_33144)
    bpy.utils.unregister_class(SNA_OT_Create_Sloped_Surface_Mesh_59F25)
