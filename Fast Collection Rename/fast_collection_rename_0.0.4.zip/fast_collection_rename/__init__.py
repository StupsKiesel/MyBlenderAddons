# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Fast Collection Rename",
    "author" : "Stups_Kiesel", 
    "description" : "Rename Collections depending on Parent Collections",
    "blender" : (3, 3, 8),
    "version" : (0, 0, 4),
    "location" : "Collection Context menu",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Outliner" 
}


import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent


addon_keymaps = {}
_icons = None
auto_update = {'sna_parents_tree': [], 'sna_parents_tree2': [], 'sna_parents_tree_reverse': [], 'sna_preset1': '', 'sna_preset2': '', 'sna_preset3': '', 'sna_preset4': '', 'sna_preset5': '', 'sna_preset6': '', }
functios = {'sna_current_col': None, 'sna_parrent_list': [], 'sna_list': [], }
ui_rename = {'sna_show_button': True, 'sna_temp_list': [], }
functios_vars_0FBFE = {'sna_parrent_list': [], 'sna_current_col': None, }


def sna_collection_parents_tree_3E0CD_0FBFE(collection):
    functios_vars_0FBFE['sna_parrent_list'] = []
    functios_vars_0FBFE['sna_current_col'] = collection
    parent_collection_0_824a2, parent_collection_name_1_824a2 = sna_parent_collection_A8036(functios_vars_0FBFE['sna_current_col'])
    functios_vars_0FBFE['sna_parrent_list'].append(parent_collection_name_1_824a2)
    functios_vars_0FBFE['sna_current_col'] = parent_collection_0_824a2
    while ('Scene Collection' != getattr(functios_vars_0FBFE['sna_current_col'], 'name', None)):
        parent_collection_0_4958b, parent_collection_name_1_4958b = sna_parent_collection_A8036(functios_vars_0FBFE['sna_current_col'])
        functios_vars_0FBFE['sna_parrent_list'].append(parent_collection_name_1_4958b)
        functios_vars_0FBFE['sna_current_col'] = parent_collection_0_4958b
    return functios_vars_0FBFE['sna_parrent_list']


def sna_string_remove_001_0ED13_F803C(String_001):
    return (String_001[:int(len(String_001) - 4.0)] if (sna_string_is_char_numeric_0CF4C_F6CD3(String_001[int(len(String_001) - 4.0):][1:][:1]) and sna_string_is_char_numeric_0CF4C_F737F(String_001[int(len(String_001) - 4.0):][1:][1:][:1]) and sna_string_is_char_numeric_0CF4C_4C516(String_001[int(len(String_001) - 4.0):][1:][1:][1:][:1]) and '.' in String_001[int(len(String_001) - 4.0):][:1]) else String_001)


def sna_string_remove_lowercase_5F74D_226B4(String):
    return String.replace('a', '').replace('b', '').replace('c', '').replace('d', '').replace('e', '').replace('f', '').replace('g', '').replace('h', '').replace('i', '').replace('j', '').replace('k', '').replace('l', '').replace('m', '').replace('n', '').replace('o', '').replace('p', '').replace('q', '').replace('r', '').replace('s', '').replace('t', '').replace('u', '').replace('v', '').replace('w', '').replace('x', '').replace('y', '').replace('z', '').replace('ü', '').replace('ä', '').replace('ö', '')


def sna_string_remove_lowercase_5F74D_8BD16(String):
    return String.replace('a', '').replace('b', '').replace('c', '').replace('d', '').replace('e', '').replace('f', '').replace('g', '').replace('h', '').replace('i', '').replace('j', '').replace('k', '').replace('l', '').replace('m', '').replace('n', '').replace('o', '').replace('p', '').replace('q', '').replace('r', '').replace('s', '').replace('t', '').replace('u', '').replace('v', '').replace('w', '').replace('x', '').replace('y', '').replace('z', '').replace('ü', '').replace('ä', '').replace('ö', '')


def sna_string_remove_001_0ED13_F775E(String_001):
    return (String_001[:int(len(String_001) - 4.0)] if (sna_string_is_char_numeric_0CF4C_F6CD3(String_001[int(len(String_001) - 4.0):][1:][:1]) and sna_string_is_char_numeric_0CF4C_F737F(String_001[int(len(String_001) - 4.0):][1:][1:][:1]) and sna_string_is_char_numeric_0CF4C_4C516(String_001[int(len(String_001) - 4.0):][1:][1:][1:][:1]) and '.' in String_001[int(len(String_001) - 4.0):][:1]) else String_001)


def sna_string_remove_001_0ED13_6CC98(String_001):
    return (String_001[:int(len(String_001) - 4.0)] if (sna_string_is_char_numeric_0CF4C_F6CD3(String_001[int(len(String_001) - 4.0):][1:][:1]) and sna_string_is_char_numeric_0CF4C_F737F(String_001[int(len(String_001) - 4.0):][1:][1:][:1]) and sna_string_is_char_numeric_0CF4C_4C516(String_001[int(len(String_001) - 4.0):][1:][1:][1:][:1]) and '.' in String_001[int(len(String_001) - 4.0):][:1]) else String_001)


def sna_string_is_char_numeric_0CF4C_F6CD3(char):
    return ('0' in char or '1' in char or '2' in char or '3' in char or '4' in char or '5' in char or '6' in char or '7' in char or '8' in char or '9' in char)


def sna_string_is_char_numeric_0CF4C_F737F(char):
    return ('0' in char or '1' in char or '2' in char or '3' in char or '4' in char or '5' in char or '6' in char or '7' in char or '8' in char or '9' in char)


def sna_string_is_char_numeric_0CF4C_4C516(char):
    return ('0' in char or '1' in char or '2' in char or '3' in char or '4' in char or '5' in char or '6' in char or '7' in char or '8' in char or '9' in char)


@persistent
def depsgraph_update_post_handler_505E0(dummy):
    collection_names_tree_0_0fbfe = sna_collection_parents_tree_3E0CD_0FBFE(bpy.context.collection)
    auto_update['sna_parents_tree'] = collection_names_tree_0_0fbfe
    auto_update['sna_parents_tree'].remove('Scene Collection')
    auto_update['sna_parents_tree_reverse'] = []
    for i_8FE89 in range(len(auto_update['sna_parents_tree'])-1,-1,-1):
        auto_update['sna_parents_tree_reverse'].append(sna_string_remove_001_0ED13_F803C(auto_update['sna_parents_tree'][i_8FE89]))


@persistent
def depsgraph_update_post_handler_38816(dummy):
    auto_update['sna_preset1'] = '_'.join(auto_update['sna_parents_tree_reverse']).replace(' ', '_')


@persistent
def depsgraph_update_post_handler_25590(dummy):
    auto_update['sna_preset2'] = sna_string_remove_lowercase_5F74D_226B4('_'.join(auto_update['sna_parents_tree_reverse']).replace(' ', '_'))


@persistent
def depsgraph_update_post_handler_A8A66(dummy):
    auto_update['sna_preset3'] = sna_string_remove_lowercase_5F74D_8BD16('_'.join(auto_update['sna_parents_tree_reverse']).replace(' ', '_')).replace('_', '')


def sna_parent_collection_A8036(collection):
    input_collection = collection
    out_parent = None
    out_parent_name = None
    out_parent = ''
    out_parent_name = ''
    bpy.data.collections[:]
    bpy.context.scene.collection
    all_collections = bpy.data.collections[:]
    all_collections.append(bpy.context.scene.collection)
    active_collection = input_collection
    parent_collection = next((collection for collection in all_collections \
        if active_collection.name in collection.children \
        ), None)
    out_parent = parent_collection
    out_parent_name = parent_collection.name
    return [out_parent, out_parent_name]


def sna_collection_parents_tree_3E0CD(collection):
    functios['sna_parrent_list'] = []
    functios['sna_current_col'] = collection
    parent_collection_0_824a2, parent_collection_name_1_824a2 = sna_parent_collection_A8036(functios['sna_current_col'])
    functios['sna_parrent_list'].append(parent_collection_name_1_824a2)
    functios['sna_current_col'] = parent_collection_0_824a2
    while ('Scene Collection' != getattr(functios['sna_current_col'], 'name', None)):
        parent_collection_0_4958b, parent_collection_name_1_4958b = sna_parent_collection_A8036(functios['sna_current_col'])
        functios['sna_parrent_list'].append(parent_collection_name_1_4958b)
        functios['sna_current_col'] = parent_collection_0_4958b
    return functios['sna_parrent_list']


def sna_string_remove_lowercase_5F74D(String):
    return String.replace('a', '').replace('b', '').replace('c', '').replace('d', '').replace('e', '').replace('f', '').replace('g', '').replace('h', '').replace('i', '').replace('j', '').replace('k', '').replace('l', '').replace('m', '').replace('n', '').replace('o', '').replace('p', '').replace('q', '').replace('r', '').replace('s', '').replace('t', '').replace('u', '').replace('v', '').replace('w', '').replace('x', '').replace('y', '').replace('z', '').replace('ü', '').replace('ä', '').replace('ö', '')


def sna_string_is_char_numeric_0CF4C(char):
    return ('0' in char or '1' in char or '2' in char or '3' in char or '4' in char or '5' in char or '6' in char or '7' in char or '8' in char or '9' in char)


def sna_string_remove_001_0ED13(String_001):
    return (String_001[:int(len(String_001) - 4.0)] if (sna_string_is_char_numeric_0CF4C_F6CD3(String_001[int(len(String_001) - 4.0):][1:][:1]) and sna_string_is_char_numeric_0CF4C_F737F(String_001[int(len(String_001) - 4.0):][1:][1:][:1]) and sna_string_is_char_numeric_0CF4C_4C516(String_001[int(len(String_001) - 4.0):][1:][1:][1:][:1]) and '.' in String_001[int(len(String_001) - 4.0):][:1]) else String_001)


class SNA_OT_Rename_Collection_3E09A(bpy.types.Operator):
    bl_idname = "sna.rename_collection_3e09a"
    bl_label = "rename_collection"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_new_name: bpy.props.StringProperty(name='new_name', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('col = bpy.data.collections.get("' + getattr(bpy.context.view_layer.active_layer_collection, 'name', None) + '")')
        exec('col.name = "' + self.sna_new_name + '"')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Open_Menu_D5824(bpy.types.Operator):
    bl_idname = "sna.open_menu_d5824"
    bl_label = "open_menu"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.call_menu(name="SNA_MT_FFD1F")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def depsgraph_update_pre_handler_86DF3(dummy):
    ui_rename['sna_show_button'] = True
    ui_rename['sna_temp_list'] = []
    for i_283D6 in range(len(bpy.context.scene.collection.children)):
        ui_rename['sna_temp_list'].append(getattr(bpy.context.scene.collection.children[i_283D6], 'name', None))


def sna_add_to_outliner_mt_collection_99E00(self, context):
    if not (getattr(bpy.context.view_layer.active_layer_collection, 'name', None) in ui_rename['sna_temp_list']):
        layout = self.layout
        op = layout.operator('sna.open_menu_d5824', text='Fast Rename ->', icon_value=0, emboss=True, depress=False)


class SNA_MT_FFD1F(bpy.types.Menu):
    bl_idname = "SNA_MT_FFD1F"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('sna.rename_collection_3e09a', text=auto_update['sna_preset1'] + '_' + sna_string_remove_001_0ED13_F775E(getattr(bpy.context.view_layer.active_layer_collection, 'name', None)), icon_value=250, emboss=True, depress=False)
        op.sna_new_name = auto_update['sna_preset1'] + '_' + sna_string_remove_001_0ED13_F775E(getattr(bpy.context.view_layer.active_layer_collection, 'name', None))
        op = layout.operator('sna.rename_collection_3e09a', text=auto_update['sna_preset2'] + '_' + sna_string_remove_001_0ED13_F775E(getattr(bpy.context.view_layer.active_layer_collection, 'name', None)), icon_value=250, emboss=True, depress=False)
        op.sna_new_name = auto_update['sna_preset2'] + '_' + sna_string_remove_001_0ED13_F775E(getattr(bpy.context.view_layer.active_layer_collection, 'name', None))
        op = layout.operator('sna.rename_collection_3e09a', text=auto_update['sna_preset3'] + '_' + sna_string_remove_001_0ED13_F775E(getattr(bpy.context.view_layer.active_layer_collection, 'name', None)), icon_value=250, emboss=True, depress=False)
        op.sna_new_name = auto_update['sna_preset3'] + '_' + sna_string_remove_001_0ED13_F775E(getattr(bpy.context.view_layer.active_layer_collection, 'name', None))
        op = layout.operator('sna.rename_collection_3e09a', text=auto_update['sna_preset1'] + '_' + sna_string_remove_001_0ED13_6CC98(getattr(bpy.context.collection.all_objects[0], 'name', None)), icon_value=235, emboss=True, depress=False)
        op.sna_new_name = auto_update['sna_preset1'] + '_' + sna_string_remove_001_0ED13_6CC98(getattr(bpy.context.collection.all_objects[0], 'name', None))
        op = layout.operator('sna.rename_collection_3e09a', text=auto_update['sna_preset2'] + '_' + sna_string_remove_001_0ED13_6CC98(getattr(bpy.context.collection.all_objects[0], 'name', None)), icon_value=235, emboss=True, depress=False)
        op.sna_new_name = auto_update['sna_preset2'] + '_' + sna_string_remove_001_0ED13_6CC98(getattr(bpy.context.collection.all_objects[0], 'name', None))
        op = layout.operator('sna.rename_collection_3e09a', text=auto_update['sna_preset3'] + '_' + sna_string_remove_001_0ED13_6CC98(getattr(bpy.context.collection.all_objects[0], 'name', None)), icon_value=235, emboss=True, depress=False)
        op.sna_new_name = auto_update['sna_preset3'] + '_' + sna_string_remove_001_0ED13_6CC98(getattr(bpy.context.collection.all_objects[0], 'name', None))


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.app.handlers.depsgraph_update_post.append(depsgraph_update_post_handler_505E0)
    bpy.app.handlers.depsgraph_update_post.append(depsgraph_update_post_handler_38816)
    bpy.app.handlers.depsgraph_update_post.append(depsgraph_update_post_handler_25590)
    bpy.app.handlers.depsgraph_update_post.append(depsgraph_update_post_handler_A8A66)
    bpy.utils.register_class(SNA_OT_Rename_Collection_3E09A)
    bpy.utils.register_class(SNA_OT_Open_Menu_D5824)
    bpy.app.handlers.depsgraph_update_pre.append(depsgraph_update_pre_handler_86DF3)
    bpy.types.OUTLINER_MT_collection.append(sna_add_to_outliner_mt_collection_99E00)
    bpy.utils.register_class(SNA_MT_FFD1F)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.app.handlers.depsgraph_update_post.remove(depsgraph_update_post_handler_505E0)
    bpy.app.handlers.depsgraph_update_post.remove(depsgraph_update_post_handler_38816)
    bpy.app.handlers.depsgraph_update_post.remove(depsgraph_update_post_handler_25590)
    bpy.app.handlers.depsgraph_update_post.remove(depsgraph_update_post_handler_A8A66)
    bpy.utils.unregister_class(SNA_OT_Rename_Collection_3E09A)
    bpy.utils.unregister_class(SNA_OT_Open_Menu_D5824)
    bpy.app.handlers.depsgraph_update_pre.remove(depsgraph_update_pre_handler_86DF3)
    bpy.types.OUTLINER_MT_collection.remove(sna_add_to_outliner_mt_collection_99E00)
    bpy.utils.unregister_class(SNA_MT_FFD1F)
